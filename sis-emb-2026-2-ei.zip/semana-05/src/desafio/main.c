// Semana 5 — Desafio: semáforo humano (3 tarefas, 0 variáveis globais de coordenação)
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include <stdio.h>

#define CICLO_MS 10000   // 5 s + 1 s + 4 s

typedef struct {
    const char *nome;
    gpio_num_t  pino;
    uint32_t    offset_ms;    // instante do ciclo em que esta cor acende
    uint32_t    duracao_ms;   // por quanto tempo fica acesa
} led_cfg_t;

// Uma única função de tarefa, reaproveitada 3x — mesmo padrão de `tarefa()` já usado
// nas Partes A-E deste lab, só que agora o "arg" carrega configuração, não só um nome.
static void tarefa_led(void *arg)
{
    const led_cfg_t *cfg = (const led_cfg_t *)arg;

    gpio_reset_pin(cfg->pino);
    gpio_set_direction(cfg->pino, GPIO_MODE_OUTPUT);
    gpio_set_level(cfg->pino, 0);

    // Alinha esta tarefa à sua fase do ciclo — só acontece UMA vez, no início.
    // vTaskDelayUntil() PROÍBE incremento 0 (configASSERT trava o sistema na hora) — a
    // tarefa "verde" tem offset_ms = 0 porque já começa no instante zero do ciclo, então
    // simplesmente pulamos a chamada nesse caso: "proximo" já está no tick certo.
    TickType_t proximo = xTaskGetTickCount();
    if (cfg->offset_ms > 0) {
        vTaskDelayUntil(&proximo, pdMS_TO_TICKS(cfg->offset_ms));
    }

    while (1) {
        gpio_set_level(cfg->pino, 1);
        printf("[%s] LIGA\n", cfg->nome);
        vTaskDelayUntil(&proximo, pdMS_TO_TICKS(cfg->duracao_ms));

        gpio_set_level(cfg->pino, 0);
        printf("[%s] desliga\n", cfg->nome);
        vTaskDelayUntil(&proximo, pdMS_TO_TICKS(CICLO_MS - cfg->duracao_ms));
    }
}

// Configuração de cada cor — estática, mas NÃO compartilhada nem escrita por ninguém:
// cada tarefa só lê a sua própria cópia (passada via arg). Isso não é uma variável de
// coordenação — é o "roteiro decorado" de cada ator, fixo desde a compilação.
static const led_cfg_t cfg_verde    = { "verde",    GPIO_NUM_2, 0,    5000 };
static const led_cfg_t cfg_amarelo  = { "amarelo",  GPIO_NUM_4, 5000, 1000 };
static const led_cfg_t cfg_vermelho = { "vermelho", GPIO_NUM_5, 6000, 4000 };

void app_main(void)
{
    xTaskCreate(tarefa_led, "verde",    2048, (void *)&cfg_verde,    3, NULL);
    xTaskCreate(tarefa_led, "amarelo",  2048, (void *)&cfg_amarelo,  3, NULL);
    xTaskCreate(tarefa_led, "vermelho", 2048, (void *)&cfg_vermelho, 3, NULL);
}