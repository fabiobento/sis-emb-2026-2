# Gabarito — Lab 5, Desafio opcional (Sistemas Embarcados, 2026/2)

---

## O enunciado, para referência

> Semáforo humano: crie as tarefas `verde`, `amarelo` e `vermelho` controlando três LEDs
> (GPIOs 2, 4, 5) com o ciclo 5 s / 1 s / 4 s. Restrição: **sem** variáveis globais de
> coordenação — cada tarefa usa apenas `vTaskDelayUntil` com offsets iniciais calculados
> para nunca colidirem.

## 1. Descrição

**O problema**: um semáforo de verdade nunca tem "duas luzes acesas ao mesmo tempo" nem "um instante escuro entre uma cor e outra" — a transição é exata. Se vocês implementassem isso com uma variável global `estado_atual` que cada tarefa lê e escreve, estariam reinventando, na mão e sem proteção nenhuma, o que a Semana 6 vai resolver "de verdade" com semáforos de sincronização (mutex/semaphore do FreeRTOS — o nome não é coincidência, é uma homenagem histórica ao sinal de trânsito). O desafio pede pra vocês sentirem, no corpo, por que esse problema existe **antes** de conhecer a ferramenta que o resolve .

**A ideia central da solução**: se três tarefas **começam a contar tempo no mesmo instante**
(quando são criadas, milissegundos umas das outras — desprezível perto de segundos) e cada
uma sabe, **desde a compilação**, exatamente em que fase do ciclo de 10 s ela deve agir, elas
não precisam **nunca** se falar durante a execução. Coordenação não exige comunicação — pode
ser combinada de antemão, como três atores que decoraram o roteiro e a deixa de entrada de cada um.

**Por que `vTaskDelayUntil` (e não `vTaskDelay`) é o que torna isso possível**: vocês já
viram na Parte C que `vTaskDelayUntil` acumula um alvo **absoluto** de tempo, não um "durma
X a partir de agora". Isso significa que cada chamada, dentro da mesma tarefa, empurra o
próximo despertar exatamente pelo incremento pedido — dá pra usar a mesma variável `proximo`
várias vezes seguidas dentro do laço, uma vez pra "ligar", outra pra "desligar", e a soma dos
incrementos sempre fecha o ciclo de 10 s certinho, sem acumular erro.

![Comparação entre vTaskDelay (período relativo, com deriva) e vTaskDelayUntil (período absoluto)](https://raw.githubusercontent.com/fabiobento/sis-emb-2026-2/main/assets/figuras/vtaskdelay_vs_until.png)

*Figura 5-C — `vTaskDelay` mede “100 ms depois de terminar” → o período inclui o trabalho e
deriva; `vTaskDelayUntil` agenda despertares absolutos → período cravado.*

**A "receita" de cada tarefa**: três números conhecidos em tempo de compilação —
- `offset`: em que instante do ciclo de 10 s essa cor **acende** pela primeira vez;
- `duração`: por quanto tempo ela fica acesa;
- o resto do ciclo (10 s − duração) é o tempo apagada.

| Cor | offset (quando acende) | duração acesa | duração apagada |
|---|---|---|---|
| verde | 0 s | 5 s | 5 s |
| amarelo | 5 s | 1 s | 9 s |
| vermelho | 6 s | 4 s | 6 s |

Repare: verde termina em 5 s, amarelo começa em 5 s e termina em 6 s, vermelho começa em 6 s
e termina em 10 s (= 0 s do próximo ciclo, onde o verde reacende). **Nunca duas cores
sobrepostas, nunca um vão sem nenhuma** — porque os três números foram escolhidos para se
encaixar como peças de quebra-cabeça, não porque as tarefas “combinaram” nada em tempo real.

## 2. Código-fonte completo da solução (versão wokwi [nesse link](https://wokwi.com/projects/477050013201202177))

```c
// Semana 5 — Desafio: semáforo humano (3 tarefas, 0 variáveis globais de coordenação)
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include <stdio.h>

#define CICLO_MS 10000   // 5 s + 1 s + 4 s

typedef struct {
    const char *nome; // para log no monitor serial
    gpio_num_t  pino; // qual GPIO controla o LED
    uint32_t    offset_ms;    // instante do ciclo em que esta cor acende
    uint32_t    duracao_ms;   // por quanto tempo fica acesa
} led_cfg_t;

// Uma única função de tarefa, reaproveitada 3x — mesmo padrão de `tarefa()` já usado
// nas Partes A-E deste lab, só que agora o "arg" carrega configuração, não só um nome.
static void tarefa_led(void *arg)
{
    const led_cfg_t *cfg = (const led_cfg_t *)arg;

    gpio_reset_pin(cfg->pino);
    gpio_set_direction(cfg->pino, GPIO_MODE_OUTPUT);
    gpio_set_level(cfg->pino, 0);

    // Alinha esta tarefa à sua fase do ciclo — só acontece UMA vez, no início.
    // vTaskDelayUntil() PROÍBE incremento 0 (configASSERT trava o sistema na hora) — a
    // tarefa "verde" tem offset_ms = 0 porque já começa no instante zero do ciclo, então
    // simplesmente pulamos a chamada nesse caso: "proximo" já está no tick certo.
    TickType_t proximo = xTaskGetTickCount();
    if (cfg->offset_ms > 0) {
        vTaskDelayUntil(&proximo, pdMS_TO_TICKS(cfg->offset_ms));
    }

    while (1) {
        gpio_set_level(cfg->pino, 1);
        printf("[%s] LIGA\n", cfg->nome);
        vTaskDelayUntil(&proximo, pdMS_TO_TICKS(cfg->duracao_ms));

        gpio_set_level(cfg->pino, 0);
        printf("[%s] desliga\n", cfg->nome);
        vTaskDelayUntil(&proximo, pdMS_TO_TICKS(CICLO_MS - cfg->duracao_ms));
    }
}

// Configuração de cada cor — estática, mas NÃO compartilhada nem escrita por ninguém:
// cada tarefa só lê a sua própria cópia (passada via arg). Isso não é uma variável de
// coordenação — é o "roteiro decorado" de cada ator, fixo desde a compilação.
static const led_cfg_t cfg_verde    = { "verde",    GPIO_NUM_2, 0,    5000 };
static const led_cfg_t cfg_amarelo  = { "amarelo",  GPIO_NUM_4, 5000, 1000 };
static const led_cfg_t cfg_vermelho = { "vermelho", GPIO_NUM_5, 6000, 4000 };

void app_main(void)
{
    xTaskCreate(tarefa_led, "verde",    2048, (void *)&cfg_verde,    3, NULL);
    xTaskCreate(tarefa_led, "amarelo",  2048, (void *)&cfg_amarelo,  3, NULL);
    xTaskCreate(tarefa_led, "vermelho", 2048, (void *)&cfg_vermelho, 3, NULL);
}
```

## 3. Saída esperada no monitor serial

```
[verde] LIGA
[verde] desliga
[amarelo] LIGA
[amarelo] desliga
[vermelho] LIGA
[vermelho] desliga
[verde] LIGA
...
```

Sempre nessa ordem, sempre um "desliga" antes do próximo "LIGA" — nunca dois "LIGA"
seguidos sem um "desliga" no meio, e o intervalo entre um "LIGA" e o próximo "LIGA" da
*mesma* cor deve ser, para as três, **10,0 s** cravados (é o mesmo `vTaskDelayUntil` sem
deriva que vocês já validaram na Parte C).

## 4. Pontos de atenção ao corrigir

- **"Sem variáveis globais de coordenação" é sobre *coordenação em tempo real*, não sobre
  `static`/`const` em si.** Os três `led_cfg_t` acima são globais no sentido de "declarados
  fora de função", mas são **somente leitura**, um por tarefa, nunca escritos depois da
  compilação, e nenhuma tarefa lê a config de outra. Isso satisfaz o espírito da restrição.
  O que **não** deve passar: qualquer variável (`estado_atual`, `semaforo_fase`, um enum
  compartilhado) que uma tarefa **escreve** e outra **lê** durante a execução — mesmo que
  "pareça" só leitura, se há escrita concorrente em algum ponto, é exatamente o problema que
  o desafio pede para evitar.
- **Offsets equivalentes são aceitáveis**: alguma dupla pode ter escolhido começar o ciclo
  no vermelho (offset 0) em vez do verde — tudo bem, desde que os três offsets mantenham a
  mesma sequência relativa (uma cor após a outra, sem sobreposição, fechando 10 s).
- **Uma função por cor, em vez de uma função parametrizada**, também é uma solução válida
  (só repete o padrão 3x com constantes diferentes hardcoded) — mais verboso, mas
  funcionalmente idêntico. Não penalizar por isso; é só uma escolha de estilo.
- **Alinhamento inicial impreciso**: se a dupla não usar `vTaskDelayUntil` também para o
  offset inicial (por exemplo, usar `vTaskDelay(cfg->offset_ms)` só na primeira vez), ainda
  funciona na prática — o desalinhamento introduzido é de µs (tempo de criação de tarefa),
  irrelevante perto de segundos. Não é o ponto central a cobrar, mas vale comentar que
  `vTaskDelayUntil` em todo lugar é mais consistente com a lição da Parte C.
- **LED errado no pino errado**: confira que verde/amarelo/vermelho batem com GPIO 2/4/5
  como pedido — é fácil trocar por engano com os pinos já vistos nos labs anteriores (LED
  do lab 3/4 estava no GPIO2, então "verde=2" tende a sair certo por hábito; os outros dois
  merecem conferência).
- **`vTaskDelayUntil` com offset 0 trava o sistema no boot — erro muito provável de
  acontecer.** Quem escolher começar o ciclo pela cor de `offset = 0` (a escolha mais óbvia,
  "verde começa no instante zero") e chamar `vTaskDelayUntil(&proximo, pdMS_TO_TICKS(0))`
  sem pensar vai ver o firmware travar **antes de qualquer `printf` aparecer**, com um
  `assert failed` genérico (sem nome de arquivo/função — a mensagem some porque o assert
  dispara com o cache de flash desligado) e reboot em loop, idêntico em hardware real e no
  Wokwi. O FreeRTOS proíbe `xTimeIncrement == 0` em `vTaskDelayUntil` — pedir para "avançar
  o alvo em zero ticks" não tem semântica válida, e o kernel aborta o sistema na checagem
  interna em vez de simplesmente ignorar. A correção do código acima (`if (cfg->offset_ms >
  0) { vTaskDelayUntil(...); }`) é o padrão certo: quando a fase é zero, a tarefa já nasce
  alinhada, não precisa (e não pode) chamar a função. Se uma dupla trombar nesse exato
  sintoma, é a primeira hipótese a verificar — é muito mais provável do que erro de fiação.

## 5. `diagram.json` para simular no Wokwi

Quem não tiver os três LEDs físicos em mãos (ou quiser conferir o ciclo visualmente antes de
ir à bancada) pode montar o circuito inteiro em simulação. Crie um projeto ESP-IDP para ESP32
em [wokwi.com/esp32](https://wokwi.com/esp32) (mesmo caminho da Semana 1, Parte B — "ESP-IDF
Templates" → "ESP32"), cole o código da seção 2 acima no `main.c` e substitua o conteúdo do
arquivo `diagram.json` do projeto por este, que já traz os três LEDs com seus resistores de
220 Ω ligados exatamente nos GPIOs 2 (verde), 4 (amarelo) e 5 (vermelho):

```json
{
  "version": 1,
  "author": "sua-bancada",
  "editor": "wokwi",
  "parts": [
    {
      "type": "board-esp32-devkit-c-v4",
      "id": "esp",
      "top": -67.2,
      "left": 43.24,
      "attrs": { "builder": "esp-idf" }
    },
    {
      "type": "wokwi-led",
      "id": "led_verde",
      "top": 0,
      "left": -30,
      "attrs": { "color": "green", "flip": "1" }
    },
    {
      "type": "wokwi-resistor",
      "id": "r_verde",
      "top": 76.8,
      "left": -30,
      "rotate": 90,
      "attrs": { "value": "220" }
    },
    {
      "type": "wokwi-led",
      "id": "led_amarelo",
      "top": 0,
      "left": -70,
      "attrs": { "color": "yellow", "flip": "1" }
    },
    {
      "type": "wokwi-resistor",
      "id": "r_amarelo",
      "top": 76.8,
      "left": -70,
      "rotate": 90,
      "attrs": { "value": "220" }
    },
    {
      "type": "wokwi-led",
      "id": "led_vermelho",
      "top": 0,
      "left": -110,
      "attrs": { "color": "red", "flip": "1" }
    },
    {
      "type": "wokwi-resistor",
      "id": "r_vermelho",
      "top": 76.8,
      "left": -110,
      "rotate": 90,
      "attrs": { "value": "220" }
    }
  ],
  "connections": [
    [ "esp:TX", "$serialMonitor:RX", "", [] ],
    [ "esp:RX", "$serialMonitor:TX", "", [] ],

    [ "r_verde:1", "led_verde:A", "green", [ "v-19.2" ] ],
    [ "led_verde:C", "esp:GND.1", "green", [ "v0" ] ],
    [ "r_verde:2", "esp:2", "green", [ "v38.4", "h128.24" ] ],

    [ "r_amarelo:1", "led_amarelo:A", "yellow", [ "v-19.2" ] ],
    [ "led_amarelo:C", "esp:GND.2", "yellow", [ "v0" ] ],
    [ "r_amarelo:2", "esp:4", "yellow", [ "v38.4", "h168.24" ] ],

    [ "r_vermelho:1", "led_vermelho:A", "red", [ "v-19.2" ] ],
    [ "led_vermelho:C", "esp:GND.3", "red", [ "v0" ] ],
    [ "r_vermelho:2", "esp:5", "red", [ "v38.4", "h208.24" ] ]
  ],
  "dependencies": {}
}
```

**Como conferir visualmente, sem olhar o monitor serial**: com o circuito montado, basta
rodar a simulação (▶) e observar os três LEDs na tela — o padrão esperado é exatamente o
"semáforo real": verde aceso 5 s, só então amarelo aceso 1 s, só então vermelho aceso 4 s, e
nunca dois LEDs acesos ao mesmo tempo nem um instante com os três apagados. É a verificação
mais rápida de que a tabela de offsets/durações da seção 1 foi implementada certa — erros de
offset tendem a aparecer como "dois LEDs piscando juntos por um instante" (sobreposição) ou
"um apagão" (vão), bem visíveis no simulador antes mesmo de ler uma linha de log.

> 💡 Se preferir não editar o JSON manualmente, o caminho alternativo é o mesmo de outros
> labs: adicione as peças pelo **+** do painel de circuito (3× LED, 3× Resistor) e ligue à
> mão — GPIO → resistor → anodo (perna longa) do LED; catodo (perna curta) → GND — repetindo
> para as três cores, nos pinos 2/4/5. O resultado final é o mesmo `diagram.json` acima.
