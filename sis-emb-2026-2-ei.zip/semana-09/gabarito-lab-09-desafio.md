# Gabarito — Lab 9, Desafio opcional: nível de bolha digital (Sistemas Embarcados, 2026/2)

> Material do **professor** (solução de referência para orientar os alunos). Código completo em
> [`src/nivel_bolha/main.c`](src/nivel_bolha/main.c); driver do OLED e barramento são idênticos ao
> [`inclinometro_oled`](src/inclinometro_oled/main.c) da Parte C.

---

## O enunciado, para referência

> **Nível de bolha digital**: use ax **e** ay para desenhar no OLED uma "bolha" (círculo) que
> desliza conforme a inclinação em 2D, como um nível de pedreiro. Dicas: mapeie ax, ay ∈
> [−0,5; +0,5] g para o raio do campo (±30 px do centro do display); desenhe o círculo com
> `px()` varrendo ângulos de 0 a 2π; **bônus** se a bolha tiver inércia (filtro passa-baixas
> de 1ª ordem nas duas coordenadas: `x += a*(alvo - x)`, com `a ≈ 0,2`).

## 1. A ideia em uma frase

Em repouso o acelerômetro mede só a gravidade; inclinar a placa **reparte o vetor g entre os
eixos** (Figura L9-F). Então `ax` e `ay` já são, diretamente, "para onde a bolha quer ir" — não
precisa de `atan2` nem de `theta`: é só converter **g → pixels** e desenhar um círculo ali.

![Quatro telas simuladas do OLED: bolha cheia no centro (nivelado), bolha deslocada para a direita, bolha para baixo e à direita, e bolha travada no anel externo](https://raw.githubusercontent.com/fabiobento/sis-emb-2026-2/main/assets/figuras/nivel_bolha_oled.png)

*Figura G9-1 — o frame buffer do OLED em quatro situações, gerado rodando o **mesmo `main.c`** em
um PC com o I²C simulado (ver seção 6). Anel externo = limite de ±30°; anel pequeno = alvo; bolha
**cheia** = nivelado.*

## 2. As contas (para conferir com a bancada)

| Decisão | Conta | Resultado |
|---|---|---|
| Escala g → pixel | ±0,5 g ↔ ±27 px | **K = 54 px/g** |
| Quanto vale ±0,5 g em ângulo | ax = sen θ → θ = arcsen 0,5 | **±30°** (o anel externo) |
| Sensibilidade perto do nível | sen 1° ≈ 0,01745 g → 0,01745 × 54 | **≈ 0,94 px por grau** |
| Deslocamento máximo do *centro* da bolha | R_CAMPO − R_BOLHA = 31 − 4 | **27 px** (a bolha nunca sai do anel) |
| Tolerância de "nivelado" | R_ALVO − R_BOLHA = 6 − 4 | **2 px ≈ 2,1°** (a mesma folga de ±2° da seta do Lab) |
| Constante de tempo da inércia | τ = −T / ln(1 − α) = 0,05 / ln(1/0,8) | **≈ 0,22 s** (α = 0,2, T = 50 ms) |
| Tempo até 90 % de um degrau | 0,8ⁿ = 0,1 → n ≈ 10,3 amostras | **≈ 0,5 s** |
| Efeito do offset de fábrica sem tara | 0,03 g × 54 | **≈ 1,6 px** por eixo (bolha "torta") |

Por que **27** e não os 30 px da dica: a bolha tem raio 4; com deslocamento de 30 px ela
atravessaria o anel (raio 31) e seria cortada na borda. Os alunos que usarem 30 px com o anel em
31 vão ver a bolha "furar" o anel — é um bom ponto de conversa sobre **tamanho do objeto ≠ posição do
centro**.

**Orçamento de tempo** (método do Exemplo 9.2 / Figura L9-I): quadro do OLED ≈ 8 × 130 bytes × 9
bits ÷ 400 kHz ≈ **23,4 ms** (+ comandos de janela, ≈ 24 ms); leitura do MPU ≈ 0,4 ms. Com período de
**50 ms (20 Hz)** o barramento fica ocupado ≈ 48 % do tempo — folgado. Por isso, diferentemente do
inclinômetro (que redesenha a cada 2 leituras), aqui redesenhamos **a cada leitura**: a bolha só
parece fluida se atualizar rápido. A 100 kHz o quadro levaria ≈ 95 ms e o laço de 50 ms **não fecharia**
(bom experimento: repetir o item 23 do lab).

## 3. Decisões de projeto que os alunos costumam errar

1. **Filtrar a leitura (g) e só depois converter para pixel e limitar.** Assim o passa-baixas
   é linear e a constante de tempo vale em qualquer posição. Filtrar *depois* do limite achata a
   dinâmica perto do anel (a bolha parece "travar" e voltar com atraso diferente).
2. **Limitar por disco, não por quadrado.** `hypotf(dx, dy) > R_MAX` → reescala os dois. Limitar
   `dx` e `dy` separadamente deixa a bolha chegar aos cantos do quadrado (fora do anel circular).
3. **Sinal do eixo y na tela.** O y do display cresce **para baixo**; por isso `dy = −SINAL_Y·gy·K`.
4. **A bolha vai para o lado ALTO.** Pela tabela do item 13, `ax > 0` quando o lado **+X** está
   mais alto; a bolha de um nível real também sobe para o lado alto. Mas qual lado do módulo está
   "+X" depende de como o GY-521 está colado na protoboard: se a bolha andar ao contrário, é
   `SINAL_X` / `SINAL_Y`, **não é bug** (mesma conversa do "θ com sinal trocado" do item 13).
5. **Tara.** O offset de fábrica (0,02–0,05 g, item 14) faz a bolha "nivelada" ficar fora do centro.
   A solução faz a média de 16 leituras no boot (**placa deitada e parada!**). Se o aluno ligar a
   placa já inclinada, a "tara" vira um erro permanente — por isso o aviso no código e no
   `printf("tara: …")`.
6. **Primeira amostra.** Sem `primeira = 1`, o filtro parte de (0, 0) e, se a placa já estiver
   inclinada, a bolha "voa do centro" por 0,5 s no boot.
7. **`memset(fb, 0, …)` a cada quadro.** Sem limpar, a bolha deixa um **rastro** (o frame buffer só
   acende pixels com `|=`).

## 4. Solução de referência (parte nova; o driver é o da Parte C)

```c
// =========================================================================
// PARÂMETROS DO DESAFIO (mexa aqui, não no meio do código)
// =========================================================================
#define PERIODO_MS   50          // 20 Hz: leitura (0,4 ms) + quadro do OLED (~24 ms) cabem folgados (Fig. L9-I)
#define ALFA         0.2f        // inércia da bolha: x += ALFA*(alvo - x)  (τ ≈ 0,22 s a 20 Hz)
#define K_PX_POR_G   54.f        // ±0,5 g  ->  ±27 px   (≈ 0,94 px por grau perto do nível)
#define CX           64          // centro do campo no display
#define CY           32
#define R_CAMPO      31          // anel externo (a tela tem 64 px de altura: 32 ± 31 cabe)
#define R_BOLHA      4
#define R_ALVO       6           // anel-alvo: a bolha "cabe" dentro dele quando está nivelado
#define R_MAX        (R_CAMPO - R_BOLHA)    // 27 px: deslocamento máximo do CENTRO da bolha
#define TOL_PX       (R_ALVO - R_BOLHA)     // 2 px (≈ 2°): dentro disto = NIVELADO
#define SINAL_X      (+1)        // se a bolha andar para o lado errado, troque o sinal
#define SINAL_Y      (+1)
#define TARA         1           // 1 = zera o offset de fábrica no boot (placa DEITADA e parada!)

// =========================================================================
// PRIMITIVAS: círculo vazio e disco cheio
// =========================================================================
// Círculo por varredura de ângulo (a dica do enunciado): x = cx + r*cos(a), y = cy + r*sin(a).
// O passo de ângulo é 1/r rad (≈ 1 px de arco) — com folga, para não deixar buracos.
static void circulo(int cx, int cy, int r)
{
    int passos = (int)(2.f * (float)M_PI * r) + 8;
    for (int k = 0; k < passos; k++) {
        float a = 2.f * (float)M_PI * k / passos;
        px(cx + (int)lroundf(r * cosf(a)), cy + (int)lroundf(r * sinf(a)));
    }
}

static void disco(int cx, int cy, int r)
{
    for (int dy = -r; dy <= r; dy++)
        for (int dx = -r; dx <= r; dx++)
            if (dx * dx + dy * dy <= r * r) px(cx + dx, cy + dy);
}

// =========================================================================
// CENA: campo + alvo + bolha. (gx, gy) = inclinação já filtrada e sem offset, em g.
// Devolve 1 se está nivelado.
// =========================================================================
static int desenha_nivel(float gx, float gy)
{
    // 1) g -> pixels. Uma bolha de nível real vai para o lado ALTO: ax > 0 quando o lado +X
    //    está mais alto (tabela do item 13), então +X da MPU empurra a bolha para +X da tela.
    //    Na tela o y cresce para BAIXO, por isso o "-" em y.
    float dx =  SINAL_X * gx * K_PX_POR_G;
    float dy = -SINAL_Y * gy * K_PX_POR_G;

    // 2) Limita o deslocamento a um DISCO de raio R_MAX (e não a um quadrado): se a placa
    //    inclina 45° nos dois eixos, a bolha encosta no anel em vez de sair pelo canto.
    float d = hypotf(dx, dy);
    if (d > R_MAX) { dx *= R_MAX / d; dy *= R_MAX / d; d = R_MAX; }

    int nivelado = (d <= TOL_PX);

    memset(fb, 0, sizeof fb);
    circulo(CX, CY, R_CAMPO);                         // anel externo = limite de ±30°
    circulo(CX, CY, R_ALVO);                          // anel-alvo no centro
    rect(CX - R_CAMPO - 0, CY, 4, 1);                 // marcas de mira nos 4 pontos cardeais
    rect(CX + R_CAMPO - 3, CY, 4, 1);
    rect(CX, CY - R_CAMPO, 1, 4);
    rect(CX, CY + R_CAMPO - 3, 1, 4);

    int bx = CX + (int)lroundf(dx), by = CY + (int)lroundf(dy);
    if (nivelado) disco(bx, by, R_BOLHA);             // bolha CHEIA = nivelado (feedback sem texto)
    else          { circulo(bx, by, R_BOLHA); px(bx, by); }   // bolha vazada com um ponto no meio
    return nivelado;
}

// =========================================================================
// LEITURA DO MPU: ax e ay em g (±2 g -> 16384 LSB/g). Devolve ESP_OK ou erro.
// =========================================================================
static esp_err_t le_ax_ay(float *ax, float *ay)
{
    uint8_t b[14];
    esp_err_t e = rd(MPU_ADDR, 0x3B, b, 14);
    if (e != ESP_OK) return e;
    *ax = (int16_t)((b[0] << 8) | b[1]) / 16384.f;    // big-endian, como na Parte B
    *ay = (int16_t)((b[2] << 8) | b[3]) / 16384.f;
    return ESP_OK;
}

void app_main(void)
{
    i2c_config_t cfg = { .mode = I2C_MODE_MASTER, .sda_io_num = SDA, .scl_io_num = SCL,
        .sda_pullup_en = GPIO_PULLUP_ENABLE, .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = 400000 };
    i2c_param_config(I2C_NUM_0, &cfg);
    i2c_driver_install(I2C_NUM_0, I2C_MODE_MASTER, 0, 0, 0);

    const uint8_t acorda[2] = { 0x6B, 0x00 };
    wr(MPU_ADDR, acorda, 2);
    oled_init();

    // ---- TARA: média de 16 leituras com a placa deitada e parada -----------------------
    // O MPU-6050 sai de fábrica com 0,02–0,05 g de offset (item 14): sem a tara, a bolha
    // "nivelada" ficaria alguns pixels fora do centro (0,03 g = 1,6 px por eixo).
    float ox = 0, oy = 0;
#if TARA
    {
        float sx = 0, sy = 0; int ok = 0;
        for (int i = 0; i < 16; i++) {
            vTaskDelay(pdMS_TO_TICKS(30));
            float ax, ay;
            if (le_ax_ay(&ax, &ay) == ESP_OK) { sx += ax; sy += ay; ok++; }
        }
        if (ok > 0) { ox = sx / ok; oy = sy / ok; }
        printf("tara: ox=%+.3f g, oy=%+.3f g (%d/16 leituras)\n", ox, oy, ok);
    }
#endif

    // ---- Estado da bolha: já FILTRADO, em g -------------------------------------------
    float fx = 0, fy = 0;
    int primeira = 1, ciclo = 0;
    TickType_t prox = xTaskGetTickCount();

    while (1) {
        vTaskDelayUntil(&prox, pdMS_TO_TICKS(PERIODO_MS));

        float ax, ay;
        if (le_ax_ay(&ax, &ay) != ESP_OK) { printf("MPU nao respondeu\n"); continue; }
        ax -= ox; ay -= oy;

        // Inércia (BÔNUS): passa-baixas de 1ª ordem nas DUAS coordenadas.
        // Na 1ª amostra parte direto da leitura, para a bolha não "vir do canto".
        if (primeira) { fx = ax; fy = ay; primeira = 0; }
        else          { fx += ALFA * (ax - fx); fy += ALFA * (ay - fy); }

        int ok = desenha_nivel(fx, fy);
        oled_flush();

        if (++ciclo % 10 == 0)                        // log a 2 Hz (não polui o monitor)
            printf("ax=%+.3f ay=%+.3f g  |  filtrado=(%+.3f, %+.3f)  %s\n",
                   ax, ay, fx, fy, ok ? "NIVELADO" : "");
    }
}
```

## 5. Rubrica sugerida (10 pontos)

| Critério | Pontos |
|---|---|
| Bolha se move nos **dois** eixos com a mesma sensibilidade (±0,5 g ↔ ±27 px) | 2 |
| Círculo desenhado por varredura de ângulo com `px()` (sem biblioteca) | 2 |
| Limite circular (a bolha nunca sai do campo) | 1 |
| **Inércia** (passa-baixas de 1ª ordem, α ≈ 0,2) com explicação de τ | 2 |
| Redesenho sem rastro e sem *flicker* (`memset` + 1 `flush` por quadro) | 1 |
| Tara ou discussão do offset de fábrica | 1 |
| Foto/vídeo + 3 linhas: o que mudou ao trocar α (0,05 / 0,2 / 0,6) | 1 |

## 6. O que foi (e o que não foi) verificado

- **Verificado em PC:** o `main.c` compila com `gcc -Wall` e roda **inteiro** (incluindo `app_main`, tara,
  filtro e desenho) contra um I²C simulado que devolve ax/ay sintéticos. Conferi: tara de
  (+0,031; −0,024) g removida (leitura 0,000), resposta ao degrau de 0,25 g igual à teoria
  (0,223 g após 10 amostras = 0,25·(1 − 0,8¹⁰)), limite circular a 45°/45°, bolha **cheia** só
  dentro de 2 px, e retorno ao centro. A Figura G9-1 é o frame buffer desse teste.
- **NÃO testado em hardware:** compilação com o ESP-IDF, o sentido real da bolha (`SINAL_X`,
  `SINAL_Y` dependem de como o módulo está montado), o aspecto no OLED físico e a medição de
  tempo do quadro (≈ 24 ms é a **conta**, não uma medida). Rode uma vez na bancada antes de passar
  aos alunos.

## 7. Extensões para quem terminar cedo

- **Sensibilidade ajustável:** `K_PX_POR_G` = 108 (±0,25 g ↔ ±27 px) dá ≈ 1,9 px/°; ótimo para
  nivelar de verdade. Pergunta: o que acontece com a faixa de ±30°?
- **Mostrar o valor:** reaproveitar `texto()` do inclinômetro para escrever ax/ay (ou os ângulos
  `atan2f(ax, az)` e `atan2f(ay, az)`) num canto.
- **Bolha com "mola e amortecimento"** (2ª ordem, em vez de α): `v += k·(alvo − x) − c·v; x += v`.
- **Calibração em 6 posições** (±1 g em cada eixo) para corrigir offset **e** ganho.
- **Trocar o passa-baixas por filtro complementar** usando o giroscópio (já está nos mesmos 14 bytes).
