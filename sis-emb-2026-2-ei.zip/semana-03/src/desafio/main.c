// Semana 3 — Desafio: clique simples x clique duplo
// Base: circuito da Parte D (pull-down externo em GPIO4)
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_timer.h"
#include <stdio.h>

#define LED   GPIO_NUM_2
#define BTN   GPIO_NUM_4
#define DEBOUNCE_MS       20   // mesmo valor já validado no experimento da Parte C
#define JANELA_DUPLO_MS   400  // tempo máximo de espera pelo 2º clique

// Máquina de estados com dois estados, conforme a dica do roteiro
typedef enum {
    AGUARDANDO_CLIQUE,          // repouso: nenhum clique pendente
    AGUARDANDO_SEGUNDO_CLIQUE   // já veio 1 clique; contando até 400 ms pelo 2º
} estado_t;

static void pisca_rapido(int *led)
{
    // Pisca 3x rápido para sinalizar clique duplo.
    // Blocante de propósito (curto o bastante para não incomodar o polling).
    for (int i = 0; i < 3; i++) {
        gpio_set_level(LED, 1);
        vTaskDelay(pdMS_TO_TICKS(80));
        gpio_set_level(LED, 0);
        vTaskDelay(pdMS_TO_TICKS(80));
    }
    // Garante que o LED termine refletindo o estado lógico atual
    gpio_set_level(LED, *led);
}

void app_main(void)
{
    gpio_reset_pin(LED);
    gpio_set_direction(LED, GPIO_MODE_OUTPUT);

    gpio_reset_pin(BTN);
    gpio_set_direction(BTN, GPIO_MODE_INPUT);
    gpio_pullup_dis(BTN);
    gpio_pulldown_dis(BTN);           // só o resistor externo de 10 kΩ define o repouso = 0

    int      led = 0;
    int      nivel_ant = 0;
    int64_t  t_ok = 0;                // debounce: instante a partir do qual aceitamos nova borda
    int      cliques = 0;

    estado_t estado = AGUARDANDO_CLIQUE;
    int64_t  t_limite_duplo = 0;      // prazo (ms) para o 2º clique chegar

    while (1) {
        int     nivel = gpio_get_level(BTN);
        int64_t agora = esp_timer_get_time() / 1000;      // ms

        // --- Detecção de clique (borda de subida + debounce), igual à Parte D ---
        int clique_detectado = 0;
        if (nivel_ant == 0 && nivel == 1 && agora >= t_ok) {
            clique_detectado = 1;
            t_ok = agora + DEBOUNCE_MS;
            printf("clique #%d (bruto)\n", ++cliques);
        }
        nivel_ant = nivel;

        // --- Máquina de estados: decide o que o clique bruto significa ---
        switch (estado) {

        case AGUARDANDO_CLIQUE:
            if (clique_detectado) {
                // Não age ainda — abre a janela de 400 ms esperando um possível 2º clique
                estado = AGUARDANDO_SEGUNDO_CLIQUE;
                t_limite_duplo = agora + JANELA_DUPLO_MS;
            }
            break;

        case AGUARDANDO_SEGUNDO_CLIQUE:
            if (clique_detectado) {
                // 2º clique chegou dentro da janela -> DUPLO
                printf("-> clique DUPLO detectado\n");
                pisca_rapido(&led);
                estado = AGUARDANDO_CLIQUE;
            } else if (agora >= t_limite_duplo) {
                // Prazo estourou sem 2º clique -> era SIMPLES
                led = !led;
                gpio_set_level(LED, led);
                printf("-> clique SIMPLES confirmado (LED = %d)\n", led);
                estado = AGUARDANDO_CLIQUE;
            }
            break;
        }

        vTaskDelay(pdMS_TO_TICKS(10));
    }
}