# Gabarito — Lab 3 (Sistemas Embarcados, 2026/2)

Uso interno do professor. Cobre os dois itens de entrega mais avançados:
1. *Diff* das mudanças da Parte D (pull-up → pull-down externo, GPIO0 → GPIO4).
2. Implementação do Desafio (clique simples × clique duplo).

---

## 1. Diff das mudanças da Parte D

Comparação entre o código-base da Parte A/B (pull-up interno, GPIO0) e o código final da
Parte D (pull-down externo, GPIO4). Gerado com `diff -u` real entre os dois arquivos —
não é uma reconstrução manual.

```diff
--- Parte A/B (pull-up interno, GPIO0)
+++ Parte D (pull-down externo, GPIO4)
@@ -1,4 +1,4 @@
-// Semana 3 — botão com pull-up interno + debounce por software (polling)
+// Semana 3 — botão com pull-down externo + debounce por software (polling)
 #include "freertos/FreeRTOS.h"
 #include "freertos/task.h"
 #include "driver/gpio.h"
@@ -6,7 +6,7 @@
 #include <stdio.h>
 
 #define LED   GPIO_NUM_2
-#define BTN   GPIO_NUM_0
+#define BTN   GPIO_NUM_4    // Mudança 1: GPIO0 é o pino de boot — não use pull-down nele
 #define DEBOUNCE_MS 20
 
 void app_main(void)
@@ -16,16 +16,19 @@
 
     gpio_reset_pin(BTN);
     gpio_set_direction(BTN, GPIO_MODE_INPUT);
-    gpio_pullup_en(BTN);              // repouso = 1; pressionado = 0
+    gpio_pullup_dis(BTN);             // Mudança 2: desabilita o pull-up interno
+    gpio_pulldown_dis(BTN);           // Mudança 3: desabilita o pull-down interno também
+                                       // (queremos só o resistor de 10 kΩ externo)
+                                       // repouso = 0; pressionado = 1
 
     int  led = 0, eventos = 0;
-    int  nivel_ant = 1;
+    int  nivel_ant = 0;                // repouso agora é 0 (antes era 1)
     int64_t t_ok = 0;                 // instante a partir do qual aceitamos nova borda
 
     while (1) {
         int nivel = gpio_get_level(BTN);
         int64_t agora = esp_timer_get_time() / 1000;      // ms
-        if (nivel_ant == 1 && nivel == 0 && agora >= t_ok) {  // borda de descida válida
+        if (nivel_ant == 0 && nivel == 1 && agora >= t_ok) {  // Mudança 4: borda de subida válida
             led = !led;
             gpio_set_level(LED, led);
             printf("evento #%d\n", ++eventos);
```

**As 4 mudanças, resumidas:**

| # | O quê | Por quê |
|---|---|---|
| 1 | `GPIO_NUM_0` → `GPIO_NUM_4` | GPIO0 é o pino de *boot strap*; pull-down nele trava o chip em modo de gravação a cada reset |
| 2 | `gpio_pullup_en` → `gpio_pullup_dis` | Desliga o pull-up interno |
| 3 | `+ gpio_pulldown_dis` | Garante que só o resistor externo de 10 kΩ define o repouso (sem pull-down interno concorrente) |
| 4 | Borda de descida (`1→0`) → borda de subida (`0→1`), e `nivel_ant` de `1` para `0` | Coerente com o novo nível de repouso (0) |

> Nota: o enunciado original do roteiro fala em "3 mudanças" (pull-up/pull-down/borda); a
> troca de GPIO0→GPIO4 foi um 4º ajuste que entrou depois, por um problema de hardware real
> descoberto durante os testes (ver `lab-03.md`, nota no início da Parte D). Vale considerar
> aceitar como corretas tanto respostas de dupla que cheguem no código com GPIO0 mas
> reportem o sintoma do boot travado, quanto as que já usaram GPIO4 preventivamente.

---

## 2. Desafio — clique simples × clique duplo

Implementação completa, construída sobre o circuito e o debounce já validados na Parte D
(GPIO4, pull-down externo, `DEBOUNCE_MS = 20`).

**Lógica da máquina de estados (2 estados, conforme a dica do enunciado):**
![](https://raw.githubusercontent.com/fabiobento/sis-emb-2026-2/main/assets/figuras/lab-03-desafio.jpeg)

```c
// Semana 3 — Desafio: clique simples x clique duplo
// Base: circuito da Parte D (pull-down externo em GPIO4)
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_timer.h"
#include <stdio.h>

#define LED   GPIO_NUM_2
#define BTN   GPIO_NUM_4
#define DEBOUNCE_MS       20   // mesmo valor já validado no experimento da Parte C
#define JANELA_DUPLO_MS   400  // tempo máximo de espera pelo 2º clique

// Máquina de estados com dois estados, conforme a dica do roteiro
typedef enum {
    AGUARDANDO_CLIQUE,          // repouso: nenhum clique pendente
    AGUARDANDO_SEGUNDO_CLIQUE   // já veio 1 clique; contando até 400 ms pelo 2º
} estado_t;

static void pisca_rapido(int *led)
{
    // Pisca 3x rápido para sinalizar clique duplo.
    // Blocante de propósito (curto o bastante para não incomodar o polling).
    for (int i = 0; i < 3; i++) {
        gpio_set_level(LED, 1);
        vTaskDelay(pdMS_TO_TICKS(80));
        gpio_set_level(LED, 0);
        vTaskDelay(pdMS_TO_TICKS(80));
    }
    // Garante que o LED termine refletindo o estado lógico atual
    gpio_set_level(LED, *led);
}

void app_main(void)
{
    gpio_reset_pin(LED);
    gpio_set_direction(LED, GPIO_MODE_OUTPUT);

    gpio_reset_pin(BTN);
    gpio_set_direction(BTN, GPIO_MODE_INPUT);
    gpio_pullup_dis(BTN);
    gpio_pulldown_dis(BTN);           // só o resistor externo de 10 kΩ define o repouso = 0

    int      led = 0;
    int      nivel_ant = 0;
    int64_t  t_ok = 0;                // debounce: instante a partir do qual aceitamos nova borda
    int      cliques = 0;

    estado_t estado = AGUARDANDO_CLIQUE;
    int64_t  t_limite_duplo = 0;      // prazo (ms) para o 2º clique chegar

    while (1) {
        int     nivel = gpio_get_level(BTN);
        int64_t agora = esp_timer_get_time() / 1000;      // ms

        // --- Detecção de clique (borda de subida + debounce), igual à Parte D ---
        int clique_detectado = 0;
        if (nivel_ant == 0 && nivel == 1 && agora >= t_ok) {
            clique_detectado = 1;
            t_ok = agora + DEBOUNCE_MS;
            printf("clique #%d (bruto)\n", ++cliques);
        }
        nivel_ant = nivel;

        // --- Máquina de estados: decide o que o clique bruto significa ---
        switch (estado) {

        case AGUARDANDO_CLIQUE:
            if (clique_detectado) {
                // Não age ainda — abre a janela de 400 ms esperando um possível 2º clique
                estado = AGUARDANDO_SEGUNDO_CLIQUE;
                t_limite_duplo = agora + JANELA_DUPLO_MS;
            }
            break;

        case AGUARDANDO_SEGUNDO_CLIQUE:
            if (clique_detectado) {
                // 2º clique chegou dentro da janela -> DUPLO
                printf("-> clique DUPLO detectado\n");
                pisca_rapido(&led);
                estado = AGUARDANDO_CLIQUE;
            } else if (agora >= t_limite_duplo) {
                // Prazo estourou sem 2º clique -> era SIMPLES
                led = !led;
                gpio_set_level(LED, led);
                printf("-> clique SIMPLES confirmado (LED = %d)\n", led);
                estado = AGUARDANDO_CLIQUE;
            }
            break;
        }

        vTaskDelay(pdMS_TO_TICKS(10));
    }
}
```

**Pontos de atenção ao corrigir entregas dos alunos:**

- **Latência esperada do clique simples**: o LED só alterna ~400 ms *depois* do clique — é
  o preço de esperar para descartar a hipótese de duplo. Alunos podem estranhar e achar que
  "não funcionou"; isso é comportamento correto, não bug.
- **`pisca_rapido` é bloqueante** (usa `vTaskDelay` dentro do loop principal, ~480 ms de
  duração total). Para este lab (sem FreeRTOS timers/tasks ainda) é aceitável; soluções que
  usam `esp_timer` por software ou uma segunda task também devem ser aceitas se o
  comportamento observável for o mesmo.
- **Debounce continua ativo** dentro da própria detecção de clique — soluções que
  removerem o debounce (`DEBOUNCE_MS`) para "simplificar" o desafio devem ser sinalizadas:
  o clique duplo ficaria contaminado por eventos fantasma do próprio bounce.
- Variações aceitáveis de nome de estados/enum, e de janela de piscar (não precisa ser
  exatamente 80 ms) — o que importa é: 1 clique → alterna LED com atraso de ~400 ms; 2
  cliques em ≤400 ms → pisca 3x e **não** conta como toggle.
