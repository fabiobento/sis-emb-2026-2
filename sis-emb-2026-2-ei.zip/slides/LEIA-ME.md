# Slides — Sistemas Embarcados

Eng. Elétrica · campus Guarapari · 5º período · 60 h (30 h teoria + 30 h laboratório)


# Índice

| Aula | Título | Slides | Arquivo |
|---|---|---|---|
| Semana 01 — teoria | Introdução aos Sistemas Embarcados | 15 | `sistemas-embarcados-semana-01` |
| Semana 02 — teoria | Arquitetura de Microcontroladores | 14 | `sistemas-embarcados-semana-02` |
| Semana 03 — teoria | C para Embarcados e GPIO em profundidade | 11 | `sistemas-embarcados-semana-03` |
| Semana 04 — teoria | Interrupções e Temporizadores | 11 | `sistemas-embarcados-semana-04` |
| Semana 05 — teoria | FreeRTOS I: Tarefas e Escalonamento | 10 | `sistemas-embarcados-semana-05` |
| Semana 06 — teoria | FreeRTOS II: Comunicação e Sincronização | 12 | `sistemas-embarcados-semana-06` |
| Semana 07 — teoria | Interfaceamento Analógico: ADC e DAC | 12 | `sistemas-embarcados-semana-07` |
| Semana 08 — teoria | Geração PWM e Acionamento de Atuadores | 12 | `sistemas-embarcados-semana-08` |
| Semana 09 — teoria | Comunicação Serial: UART, SPI e I2C | 12 | `sistemas-embarcados-semana-09` |
| Semana 10 — teoria | Barramento CAN e o Controlador TWAI | 10 | `sistemas-embarcados-semana-10` |
| Semana 11 — teoria | Linux Embarcado e o Raspberry Pi | 13 | `sistemas-embarcados-semana-11` |
| Semana 12 — teoria | Interfaceamento Físico no Linux Embarcado | 13 | `sistemas-embarcados-semana-12` |
| Semana 13 — teoria | PDS Embarcado e Controle: fechando a malha | 13 | `sistemas-embarcados-semana-13` |
| Semana 14 — teoria | Wi-Fi, MQTT e a arquitetura ESP32 + Raspberry Pi | 13 | `sistemas-embarcados-semana-14` |
| Semana 15 — teoria | Avaliação P2 e Apresentação dos Projetos | 5 | `sistemas-embarcados-semana-15` |
| Semana 01 — laboratório | Ambientação: Ubuntu, ESP-IDF e Wokwi | 9 | `sistemas-embarcados-lab-01` |
| Semana 02 — laboratório | ESP-IDF no hardware: build, flash, monitor | 10 | `sistemas-embarcados-lab-02` |
| Semana 03 — laboratório | GPIO de E/S e o experimento do bouncing | 8 | `sistemas-embarcados-lab-03` |
| Semana 04 — laboratório | Interrupção, timer periódico e watchdog | 8 | `sistemas-embarcados-lab-04` |
| Semana 05 — laboratório | Tarefas, prioridades, deriva e dual-core | 9 | `sistemas-embarcados-lab-05` |
| Semana 06 — laboratório | Vendo a corrida acontecer (e consertando) | 9 | `sistemas-embarcados-lab-06` |
| Semana 07 — laboratório | Lendo o mundo: LDR, filtro e senoide no DAC | 8 | `sistemas-embarcados-lab-07` |
| Semana 08 — laboratório | PWM na prática: dimmer, servo e motor DC | 9 | `sistemas-embarcados-lab-08` |
| Semana 09 — laboratório | I2C na veia: scanner, MPU-6050 e display | 8 | `sistemas-embarcados-lab-09` |
| Semana 10 — laboratório | Uma rede CAN de verdade com dois ESP32 + TWAI | 9 | `sistemas-embarcados-lab-10` |
| Semana 11 — laboratório | RPi headless: do cartão virgem ao sistema por SSH | 9 | `sistemas-embarcados-lab-11` |
| Semana 12 — laboratório | GPIO, DHT11 e HC-SR04 no Raspberry Pi | 9 | `sistemas-embarcados-lab-12` |
| Semana 13 — laboratório | Malha fechada de luminosidade com PID | 9 | `sistemas-embarcados-lab-13` |
| Semana 14 — laboratório | A arquitetura completa: ESP32 → MQTT → RPi | 9 | `sistemas-embarcados-lab-14` |
| Lab extra — medidor de energia | Medição de energia real: CA, fator de potência e Modbus | 21 | `sistemas-embarcados-lab-extra-energia` |
| Lab extra — TinyML | Classificador de movimento no ESP32 (Edge Impulse + MPU-6050) | 8 | `sistemas-embarcados-lab-extra-tinyml` |
| Projeto final | Projeto Final Integrador | 13 | `sistemas-embarcados-projeto-final` |

## Como estão organizados

**Decks de teoria** — abertura com gancho, seções numeradas, exemplos resolvidos destacados em
cartões, caixas âmbar para armadilhas e anti-padrões, e slide final "Resumindo" com a faixa
"Onde estudar / Exercícios".

**Decks de laboratório** — capa com selo âmbar "● LABORATÓRIO" para não se confundirem com a
teoria. Formato híbrido: slides de projeção para os marcos das partes A, B, C… combinados com o
guia completo — blocos de terminal com os comandos exatos, tabelas prontas para o aluno preencher,
caixas de "erro provocado" e slide de entrega com checklist e desafio opcional.

**Figuras** — as caixas tracejadas marcam onde inserir figuras dos livros do acervo, com a
referência exata (livro, figura, capítulo e página) já verificada.

## Observações

- O lab extra de energia envolve rede de 220 V. O segundo slide é o aviso de segurança e deve ser
  lido na íntegra antes de qualquer montagem; o lado CA é exclusivo do professor.
- O deck do projeto final é para apresentar na semana 10 (entrega das propostas); vale mostrar
  uma versão resumida na semana 1.
- Os geradores em JavaScript (pptxgenjs) que produzem estes arquivos ficam fora deste pacote —
  peça se quiser editar em lote.
