# GABARITO — Lista 02 (uso exclusivo do professor)

**Q1.** Polling: latência de pior caso = período de varredura; gasta CPU proporcional à
frequência de varredura mesmo sem eventos; simples e determinístico. Interrupção: latência de
µs, CPU só quando há evento; complexidade maior (concorrência, reentrância). Polling é a escolha
certa para sinais lentos/sempre presentes (teclado varrido, sensores lentos) ou quando se quer
temporização trivialmente previsível num super-loop.

**Q2.** Pulso de 400 µs com varredura de 2 ms: o pulso inteiro cabe entre duas leituras ⇒
perdido. Amostragem confiável exige período < largura do pulso (≈2 leituras por pulso):
T ≤ 200 µs (5 kHz). A 5 kHz de polling, o custo de CPU já é relevante e a contagem fica frágil
a jitter ⇒ ISR por borda (ou o contador de pulsos/PCNT) se impõe.

**Q3.** (i) Curta: ISR longa atrasa todas as outras e estoura prazos (jitter global).
(ii) Nada bloqueante (delay, printf, malloc, mutex): risco de deadlock/latência não determinística
— printf na ISR foi o travamento demonstrado no Lab 4. (iii) `FromISR` + `IRAM_ATTR`: APIs comuns
podem escalonar de forma ilegal no contexto de exceção; código fora da IRAM pode estar em Flash
ocupada (cache miss durante escrita de Flash ⇒ crash).

**Q4.** Alvo: 0,25 s. Opção 1: prescaler 80 (tick 1 µs) e comparação 250 000. Opção 2:
prescaler 8000 (tick 100 µs) e comparação 2500. Ambas exatas; preferir tick de 1 µs pela
resolução/reuso (padrão do curso e do `esp_timer`), contadores de 64 bits não estouram na prática.

**Q5.** Contador de hardware que reinicia o sistema se não for realimentado no prazo; mitiga
travamentos de software (laços infinitos, deadlock). Alimentar na ISR de timer é anti-padrão
porque a ISR continua viva mesmo com o laço principal travado ⇒ o WDT nunca dispara e perde a
função (deve-se alimentar no fluxo que se quer vigiar).

**Q6.** Transições esperadas: criada→pronta; pronta→executando (escalonador escolhe);
executando→bloqueada (`vTaskDelay`, `xQueueReceive` sem dado); bloqueada→pronta (timeout expira,
dado chega); executando→pronta (preempção por prioridade maior — ex.: tarefa do LED de 200 ms
preempta o log); suspensa via `vTaskSuspend` (usada no experimento 4 do Lab 5).

**Q7.** `vTaskDelay` conta a partir do **fim** do corpo: período = 107 ms. Deriva ≈ 7 ms por
ciclo; em 1 min (~561 ciclos de 107 ms) acumula ~3,9 s de atraso versus o cronômetro ideal
(aceitar 60 s × 7/107 ≈ 3,9 s). `vTaskDelayUntil` agenda pelo **instante absoluto** anterior:
período exatamente 100 ms, sem acúmulo (jitter apenas local).

**Q8.** Utilização: A = 30 %, B = 10 % ⇒ 40 %; C roda nos 60 % restantes. Prioridades:
A > B > C (menor período/mais crítica primeiro — racional de taxa monotônica). Se B passa a
60 ms/100 ms: total 90 %, C ainda roda mas raramente (10 %); pior: B (10 ms de resposta exigida)
continua ok, porém qualquer tarefa extra ou ISR pesada leva a perder prazos — discutir margem.

**Q9.** Starvation: tarefa pronta que nunca recebe CPU por haver sempre prioridade maior pronta.
Mesma prioridade: FreeRTOS faz *round-robin* por tick (time slicing), alternando as prontas.
`while(1)` sem bloqueio em prioridade alta: nunca cede ⇒ tarefas menores (inclusive a *idle*)
nunca rodam; o **task WDT da idle** dispara e imprime o aviso (visto no Lab 5, experimento 3).

**Q10.** Pinning no core 1 isola o controle do jitter das pilhas de rede (que rodam no core 0)
⇒ período mais estável (medimos isso no Lab 5). Cuidado: perde-se balanceamento automático;
tarefa presa num core saturado não migra, e estruturas compartilhadas entre cores continuam
precisando de sincronização (spinlocks internos têm custo).

**Q11.** Perda: A lê g=k; preempção; B lê k, escreve k+1 (várias vezes); A volta e escreve k+1,
sobrescrevendo os incrementos de B. Intervalo do resultado com 1000+1000 incrementos:
**de 2 a 2000** (o mínimo teórico é 2 com entrelaçamento patológico; aceitar "entre 1000 e 2000"
como resposta prática, mas bonificar quem demonstra < 1000). Correções: mutex em volta do
`g++`; ou cada tarefa incrementa contador próprio e uma terceira soma (sem exclusão);
(mencionar atômicos como alternativa avançada).

**Q12.** Aceitar tabela equivalente a:
| Primitivo | Carrega | Uso típico no curso | De ISR? |
|---|---|---|---|
| Fila | cópias de dados (N itens) | amostras ADC ISR→tarefa (Lab 6) | sim (`FromISR`) |
| Sem. binário | 1 sinal | "aconteceu um evento" (botão) | give sim |
| Sem. contagem | N sinais | contar eventos em rajada | give sim |
| Mutex | posse + herança | proteger recurso (printf, I2C) | **não** |
| Event group | máscara de bits | esperar Wi-Fi **e** MQTT (semana 14) | set sim (c/ ressalvas) |

**Q13.** Produção: 2000 amostras/s × 0,04 s = 80 amostras entre acordadas ⇒ fila ≥ 80 itens;
com folga 2×: **160 itens × 4 B = 640 B**. Sem folga, um bloqueio extra de 60 ms acumula
2000×0,1 = 200 > 160… (mostrar conta: 0,1 s × 2 kHz = 200 itens) ⇒ fila cheia, `xQueueSendFromISR`
falha e amostras são descartadas — exatamente o overflow demonstrado no Lab 6 com carga Wi-Fi.

**Q14.** Inversão: tarefa de alta prioridade H bloqueia num recurso preso pela baixa L, e uma
média M (que não usa o recurso) preempta L ⇒ H espera M indefinidamente. Pathfinder (1997): a
tarefa de barramento (alta) esperava mutex do buffer preso pela tarefa meteorológica (baixa),
enquanto a de comunicações (média) rodava; o WDT reiniciava a sonda; correção enviada da Terra
ativou herança de prioridade. Herança: enquanto L possui o mutex requisitado por H, L herda a
prioridade de H e termina logo; semáforo binário não tem dono ⇒ não há de quem herdar.

**Q15.** Núcleo esperado:
```c
static SemaphoreHandle_t sem;

static void IRAM_ATTR isr_botao(void *arg) {
    BaseType_t acordou = pdFALSE;
    xSemaphoreGiveFromISR(sem, &acordou);
    portYIELD_FROM_ISR(acordou);          /* troca de contexto imediata se preciso */
}

void tarefa_botao(void *p) {
    for (;;) {
        xSemaphoreTake(sem, portMAX_DELAY);   /* dorme sem gastar CPU */
        /* debounce + ação demorada aqui (log, I2C, etc.) */
    }
}
```
Pesado na tarefa: ISR fica em µs (regra Q3), o trabalho ganha prioridade ajustável, pode usar
APIs bloqueantes e ser preemptado sem travar o sistema.
