# GABARITO — Lista 01 (uso exclusivo do professor)

**Q1.** Sistema computacional dedicado, embutido num produto, com função específica e restrições
de projeto. Exemplos (aceitar variações coerentes): tempo real — airbag/ABS; energia — sensor
IoT a bateria; custo — controle de micro-ondas (milhões de unidades); memória — cartão
inteligente; confiabilidade — marcapasso/aviônica.

**Q2.** (a) MCU (tempo real rígido, certificação, simplicidade); (b) MPU/SoC com Linux (pilhas
de rede complexas, throughput); (c) FPGA (paralelismo/algoritmo proprietário, protótipo de HW);
(d) MCU com deep sleep (energia dominante). Penalizar respostas sem amarração às restrições.

**Q3.** Ciclo de 600 s: ativo 3 s × 120 mA = 360 mA·s; dormindo 597 s × 0,04 mA = 23,9 mA·s.
I_médio = 383,9/600 ≈ **0,64 mA**. Autonomia = 1200/0,64 ≈ **1875 h ≈ 78 dias**.
Domina a transmissão (360 ≫ 23,9). Dobrar autonomia por software: transmitir a cada 20 min
(I_médio ≈ 0,34 mA → ~147 dias) ou reduzir o tempo ativo (agregação de posições).

**Q4.** Rígido: perder o prazo = falha do sistema (airbag: disparo em ms). Brando: perder
degrada qualidade (multimídia do painel atrasar um frame). A malha de luminosidade é **soft**:
um período de 20 ms perdido só degrada levemente o controle — mas discutir que jitter excessivo
degrada estabilidade (gancho com semana 13).

**Q5.** Simulador: itera rápido, sem risco de queimar componente, permite estudar em casa e
"congelar" o tempo (depuração). Limitações (duas quaisquer): não modela eletrônica analógica
real (ruído, quedas de tensão, contato de protoboard), timing não é fiel ao ciclo (Wokwi não
garante tempo real), periféricos limitados/idealizados, sem Wi-Fi real com latência de rede
verdadeira (o Wokwi tem gateway próprio).

**Q6.** Von Neumann: barramento único código+dados (gargalo, mas simples). Harvard:
barramentos separados → busca de instrução simultânea a acesso de dado, essencial p/
determinismo e desempenho com memórias distintas (Flash p/ código, SRAM p/ dados). ESP32:
Harvard **modificada** — espaços separados (IRAM/DRAM), mas com pontes que permitem, p.ex.,
executar da RAM (`IRAM_ATTR`, semana 4).

**Q7.** 12 000 instr × 1 kHz = 12 Minstr/s. Em 240 MHz: 12/240 = **5 %** de um núcleo.
Em 16 MHz: 12/16 = **75 %** — inviável somado a qualquer outra coisa. Conclusão: para PDS/controle
com folga (e Wi-Fi junto), o ESP32; o AVR fica para E/S simples.

**Q8.** Flash: não volátil, lenta (com cache), guarda código e constantes; SRAM: volátil,
rápida, dados/pilha/heap; RTC RAM: pequena, permanece energizada no deep sleep (estado entre
acordadas). Globais inicializadas: seção `.data` — **valores** gravados na Flash, **copiados**
pelo startup para SRAM antes de `app_main` (é o custo de boot que medimos na semana 2).

**Q9.**
```c
volatile uint32_t *w1ts = (volatile uint32_t *)0x3FF44008;
*w1ts = (1u << 2);            /* liga GPIO2 */
```
`W1TS/W1TC` são atômicos no periférico: escrever 1 seta/limpa só aqueles bits, sem ler o
registrador → elimina a janela de corrida do read-modify-write entre tarefas/ISR (liga com 6.1).

**Q10.** 3 eixos × 2 B × 1000 Hz × 5 s = **30 KB** → cabe com folga na SRAM.
60 s → 360 KB: tecnicamente < 520 KB, mas **não cabe na prática** (heap disponível ~300 KB com
Wi-Fi etc.). Solução: gravar em Flash/SD por streaming — NVS não (pequena/lenta p/ stream);
correto: FATFS em SD (curso Mair, seção *storage*: SD-SPI/MMC) ou enviar por rede em blocos.

**Q11.** `volatile` impede: manter a variável em registrador, eliminar releituras e reordenar
acessos. Sem ele: `while (!flag);` com `flag` setada na ISR vira laço infinito após otimização
(-O2), pois o compilador "sabe" que ninguém no fluxo visível altera `flag`. Citar que volatile
**não** dá atomicidade (ponte p/ mutex, semana 6).

**Q12.** Zerar 3–2 e escrever 01: `r = (r & ~(0x3u << 2)) | (0x1u << 2);`
Inverter bit 7: `r ^= (1u << 7);`

**Q13.** R = (3,3 − 3,0)/0,004 = **75 Ω** (usar 68–82 Ω comercial); margem de só 0,3 V ⇒ grande
sensibilidade a variação de V_F → na prática usa-se corrente menor ou LED de V_F menor.
Em 5 V: R = (5 − 3,0)/0,004 = 500 Ω. GPIOs de 3,3 V **não toleram 5 V**: injetar 5 V supera o
máximo absoluto, dispara os diodos de proteção e degrada/queima o pino (RPi não tem proteção
de sobra — Molloy alerta no cap. 6). Interligação 5 V↔3,3 V exige divisor/conversor de nível
(temos 4 no inventário; ver também Molloy, Figura 8-22, p. 360).

**Q14.** Pull-up: resistor ao V_cc; entrada repousa em 1; botão ao GND ⇒ pressionado lê 0
(lógica ativa-baixa). Pull-down: espelhado (repousa 0, pressionado 1). Circuito: GPIO—botão—GND
com pull-up interno habilitado. Solto = 1, pressionado = 0.

**Q15.** Janela deve exceder o bouncing com margem: 6 ms → escolher **10–20 ms** (usamos 20 ms
no Lab 3). Técnica aceita: ao detectar borda, ignorar novas bordas pela janela; ou confirmar
estado estável por N leituras consecutivas. Compromisso: janela maior = mais imunidade, porém
mais latência percebida; 20 ms é imperceptível ao usuário (< 50 ms) e robusto para botões
tácteis comuns.

**Q16 (bônus).** Pipeline: estágios sobrepostos ⇒ vazão de ~1 instrução/ciclo apesar da latência
individual de várias etapas; superescalar multiplica isso. Cache: mantém instruções/dados
quentes em SRAM rápida, evitando esperar a DRAM. MAS ambos tornam o tempo de execução
**dependente do histórico**: um miss de cache ou uma predição errada custa dezenas de ciclos em
momentos imprevisíveis ⇒ jitter. MCU sem cache executando da flash/SRAM com tempos fixos perde
em vazão e ganha em determinismo — exatamente o critério de escolha da semana 1 (tempo real
rígido → MCU).
