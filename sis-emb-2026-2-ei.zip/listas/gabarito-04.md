# GABARITO — Lista 04 (uso exclusivo do professor)

**Q1.** Exigem Linux: pilhas complexas (câmera + visão computacional, TCP/IP avançado, banco de
dados, multiusuário), sistema de arquivos/atualizações, ecossistema Python/OpenCV. Desaconselham:
tempo real rígido em µs, consumo de mW/bateria, custo unitário mínimo, boot instantâneo.
Câmera com detecção: RPi (ou RPi+aceleração) — precisa de SO e bibliotecas. Fechadura a bateria:
ESP32/MCU — deep sleep de µA e resposta imediata; o RPi consome ~2–4 W e leva ~30 s para bootar.

**Q2.** (1) BootROM na GPU lê o cartão; (2) `bootcode.bin` (2ª etapa) carrega; (3) firmware
`start.elf` lê `config.txt`, configura clocks/memória e carrega kernel + device tree (+overlays);
(4) kernel monta rootfs e entrega ao `systemd` (runlevel/serviços). Overlay de I2C: etapa 3 —
`dtparam=i2c_arm=on`/`dtoverlay=` no `config.txt` (o raspi-config só edita isso).

**Q3.** Linux é multitarefa preemptivo de propósito geral: o processo pode ser preemptado por
outros, por IRQs, migração de CPU, page-fault; em Python soma-se o GC/interpretador ⇒ pausas de
ms imprevisíveis. No ESP32, a ISR de timer tem prioridade de hardware e latência determinística
de µs; não há outros processos. `PREEMPT_RT`: patch/config do kernel que torna quase tudo
preemptível e converte handlers em threads ⇒ latências de pior caso na casa de dezenas de µs —
melhora muito, mas ainda não substitui MCU para malhas rápidas.

**Q4.** `/sys` e `/proc`: sistemas de arquivos virtuais que expõem kernel/hardware como
arquivos (a "API de arquivos" do Linux). (a) `cat /sys/class/thermal/thermal_zone0/temp` (m°C);
(b) `cat /proc/device-tree/model` (ou `cat /proc/cpuinfo`); (c)
`echo none | sudo tee /sys/class/leds/led0/trigger` seguido de
`echo 1 | sudo tee /sys/class/leds/led0/brightness` (aceitar `ACT` no lugar de `led0` conforme a
versão do SO).

**Q5.** Sequência aceita (variações ok):
```bash
sudo adduser aluno
sudo usermod -aG gpio,i2c,spi aluno
sudo apt update && sudo apt full-upgrade -y
sudo raspi-config nonint do_i2c 0        # 0 = habilita
# alternativa: echo 'dtparam=i2c_arm=on' | sudo tee -a /boot/firmware/config.txt && sudo reboot
```

**Q6.** microSD: NAND com ciclos de escrita limitados e controladores simples ⇒ desgaste e
corrupção em quedas de energia; eMMC/SSD têm wear-leveling melhor. Práticas (duas): reduzir
escrita (log em RAM/`tmpfs` com flush periódico, `journald` volátil), desligar swap, usar
cartões A1/A2 de marca, `overlayfs`/somente-leitura para o rootfs, desligamento limpo/UPS.

**Q7.** sysfs: obsoleto (removido nos kernels novos), lento, mas "só shell" — bom para
demonstração histórica. libgpiod (cdev): API oficial atual, rápida (para Linux), C/CLI
(`gpioset/gpioget`), certo para daemons e código portável. gpiozero: Python de altíssimo nível
(objetos LED/Button/DistanceSensor), perfeito para ensino e prototipagem; desempenho menor.
Teste rápido → gpiozero (ou gpioset); daemon em C → libgpiod; aula introdutória → gpiozero.

**Q8.** Corte de custo/uso-alvo do SoC (multimídia, não aquisição) e a filosofia "delegue ao
periférico certo". Saídas: (i) **ADC externo SPI/I2C** (MCP3008/ADS1115) — geral, multicanal;
(ii) **sensor já digital** (DHT11, DS18B20, MPU-6050) — quando existir equivalente; (iii)
**MCU auxiliar** (ESP32/Arduino faz o analógico e manda por serial/MQTT) — quando também há
tempo real envolvido (nossa arquitetura da semana 14).

**Q9.** V_out = 5·R2/(R1+R2) = 3,3 ⇒ R2 = 3,3·R1/(5−3,3) = 3,3·1,5k/1,7 ≈ **2,91 kΩ**
(usar 2,7 k ou 3 k; com 2,7 k: V_out = 3,21 V ✔). Corrente: I = 5/(R1+R2) = 5/4,41k ≈ **1,13 mA**
— desprezível para o driver do ECHO.

**Q10.** d = v·t/2 = 343·0,00175/2 ≈ **0,30 m**. Timeout de 30 ms ⇒ d_max = 343·0,030/2 ≈
**5,1 m** (coerente com o alcance de ~4 m do sensor: o timeout cobre o alcance físico).

**Q11.** O protocolo do DHT11 codifica bits em larguras de 26–70 µs; uma preempção de alguns ms
no meio da leitura corrompe o quadro ⇒ falhas intermitentes (CRC). Estratégias: (i) usar driver
de kernel/biblioteca que tolere e re-tente (ler até checksum ok — nosso `dht11_log.py` re-tenta);
(ii) delegar o timing a hardware/MCU: ler via ESP32/Arduino e receber por serial/MQTT, ou usar
sensores I2C (SHT/BME) sem timing crítico; (aceitar: prioridade RT no processo — melhora, não
resolve).

**Q12.** Arquitetura esperada: MPU-6050 e OLED no **I2C** (endereços distintos 0x68/0x3C, mesmos
2 fios, pull-ups já nos módulos); botão em **GPIO** com pull-up interno e debounce; CSV no
cartão com flush periódico (Q6!). Software: gpiozero (Button) + `smbus2`/driver Python p/ MPU +
`luma.oled`/`ssd1306` p/ display; loop a 100 Hz gravando em buffer e escrevendo em bloco.
Cuidados elétricos: tudo em 3,3 V (nenhum módulo de 5 V no I2C sem conversor de nível),
GND comum, alimentação do OLED conferida. Bonificar quem citar systemd para autostart e
desligamento limpo.
