# GABARITO — Lista 05 (uso exclusivo do professor)

**Q1.** Banda ≈ 1/(2π·2) ≈ 0,08 Hz. Regra 10–30× ⇒ f_s ≈ **1–2,5 Hz** (aceitar 1–10 Hz).
10 kHz: nenhuma informação nova entre amostras (processo não muda), CPU/energia à toa e, pior,
a derivada e = (e_k−e_{k−1})/T_s divide variações minúsculas por T_s minúsculo ⇒ amplifica
ruído do ADC; além de encher logs/fila sem ganho de controle.

**Q2.** Zeros da média móvel em k·f_s/M. Queremos zero em 60 Hz: f_s/M = 60 ⇒ M = 500/60 ≈ 8,33.
M inteiro: **M = 8** dá zeros em 62,5; 125; ... (atenuação grande, não nula) — bonificar quem
propõe **f_s = 480 Hz com M = 8** (zero exato em 60 Hz) ou cascata de duas médias. Atraso de
grupo: (M−1)/2 = 3,5 amostras = 3,5/500 = **7 ms** (ok para sinal de 5 Hz).

**Q3.** u_k = K_p·e_k + K_i·T_s·Σe_i + K_d·(e_k − e_{k−1})/T_s. P: reação imediata ao erro
(excesso ⇒ oscilação); I: zera erro em regime — compensa luz ambiente constante (excesso ⇒
oscilação lenta/windup); D: amortece/antecipa mudanças (excesso ⇒ amplifica ruído do LDR).
(Aceitar forma incremental equivalente.)

**Q4.** It. 1: e=20; P=24; I=3,0·0,02·20=1,2; u₁=**25,2**. It. 2: e=14; P=16,8; acumulado
I=1,2+3,0·0,02·14=2,04; u₂=**18,84**. Sem saturação (ambos em [0,100]). Conferir que o aluno
acumula o I entre iterações.

**Q5.** Windup: com o atuador saturado, o erro persiste e o integrador cresce sem efeito;
quando a referência volta a ser alcançável, o I "gigante" mantém u saturado e causa sobressinal
e recuperação lenta. No lab: pedir luminosidade alta com o copo aberto (LED no máximo não
alcança) — ao fechar o copo, a malha sem anti-windup dispara. Clamping: só integra quando a
saída **não** está saturada (ou quando o erro reduziria a saturação) — testado com
`ANTI_WINDUP 0/1` no firmware.

**Q6.** D usa diferença dividida por T_s: se o intervalo real varia (jitter), a derivada
calculada com T_s nominal fica errada na proporção do jitter ⇒ picos falsos. `vTaskDelayUntil`
garante período absoluto no ESP32 (jitter de µs). No RPi, preempções de ms (Exemplo 11.1) em um
laço de 20 ms geram 10–50 % de erro instantâneo no D ⇒ malhas rápidas ficam no MCU; o RPi
supervisiona (arquitetura da semana 14).

**Q7.** Todos falam com o broker: produtores publicam em tópicos; consumidores assinam.
Vantagens: desacoplamento (ninguém conhece endereço de ninguém; nós entram/saem livremente),
escala (novo painel = nova assinatura, zero mudança nos nós), resiliência/assimetria (retained,
LWT, buffering; nós dormem e o dado fica). Nosso broker: **Mosquitto no RPi 3** (borda).

**Q8.** Exemplo aceito: `estac/p<1..3>/v<01..20>/ocupada` (QoS 0 — estado re-publicado; ou QoS 1
retained para restauração de painel: aceitar com justificativa), `estac/p2/+/ocupada` (painel do
piso 2), `estac/#` (auditoria), `estac/cancela/cmd` **QoS 1 + retained NÃO** (comando não deve
ser re-executado por um assinante novo ⇒ retain só em `estac/cancela/estado`). Avaliar coerência
da justificativa mais que a árvore exata.

**Q9.** QoS 0: entrega no máximo 1×, sem confirmação — telemetria periódica (temp a cada 5 s).
QoS 1: ao menos 1× (PUBACK), pode duplicar — comando de LED/ventilador (idempotente).
QoS 2: exatamente 1× (handshake duplo), mais tráfego/latência — evento crítico não idempotente
(ex.: incrementar contador de acesso, registro de cobrança).

**Q10.** LWT: mensagem que o **broker** publica em nome do cliente se a sessão cair sem
DISCONNECT (keepalive estourado). TCP não avisa os *outros* interessados: a conexão morta é
entre nó e broker; os assinantes nada veem. Com LWT em `ifes/bancadaN/status` (retained),
qualquer painel sabe on/offline. No lab: desligamos o USB do ESP32 e vimos `offline` chegar
~10 s depois (keepalive 5 s + margem).

**Q11.** Ciclo 120 s: ativo 3×90 = 270 mA·s; dormindo 117×0,015 = 1,755 mA·s ⇒ I = 271,755/120
≈ **2,26 mA** ⇒ 1500/2,26 ≈ 663 h ≈ **27,6 dias**. A cada 600 s: I = (270+597·0,015)/600 =
278,96/600 ≈ 0,465 mA ⇒ 3226 h ≈ **134 dias**. Domina o **tempo ativo com rádio** (duty cycle
de transmissão) — o sono de 15 µA é quase grátis; projeto = minimizar acordadas e o tempo
conectado (Wi-Fi rápido, QoS 0, payload curto).

**Q12.** Fluxo: `esp_wifi_start` → `WIFI_EVENT_STA_START` → `esp_wifi_connect` →
`IP_EVENT_STA_GOT_IP` → handler seta BIT_GOT_IP → main desbloqueia e chama `mqtt_start` →
`MQTT_EVENT_CONNECTED` seta BIT_MQTT_OK → main entra no laço de publicação. Bloquear no event
group não gasta CPU (tarefa sai de pronta) e elimina corrida "publicar sem IP". Na queda:
`WIFI_EVENT_STA_DISCONNECTED` limpa BIT_GOT_IP e re-chama `esp_wifi_connect`; o cliente MQTT
re-conecta sozinho e re-publica `online` (retained) — o LWT `offline` publicado pelo broker é
substituído.

**Q13 (bônus).** REST/polling: cliente pergunta a 2 Hz ⇒ 7200 req/h por aba, latência média =
metade do período de polling (250 ms), mas é o mais simples e stateless. WebSocket: 1 conexão
persistente, servidor empurra ⇒ tráfego só quando há dado, latência ~ms; exige servidor
assíncrono. MQTT-over-WS: o navegador vira mais um assinante do broker ⇒ zero código de ponte,
consistência com os nós; acrescenta dependência do broker exposto ao navegador. Resposta
esperada: WebSocket (ou MQTT-over-WS) para a telemetria + REST para o comando (esporádico e
idempotente); aceitar qualquer escolha bem justificada com os três eixos.
