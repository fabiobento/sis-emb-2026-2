# GABARITO — Lista 03 (uso exclusivo do professor)

**Q1.** Níveis = 4096. LSB = 3,1/4096 ≈ **0,757 mV**. Leitura p/ 1,20 V:
1,20/0,000757 ≈ **1585** (aceitar 1584–1586). Erro máx. de quantização = ±LSB/2 ≈ **±0,38 mV**.

**Q2.** Sensor em cima, fixo (R=10 k) embaixo: V_out = 3,3·10k/(R_s+10k).
R_s=5 k → 3,3·10/15 = **2,20 V**; R_s=50 k → 3,3·10/60 = **0,55 V**; ΔV = **1,65 V**.
Com 22 k: 3,3·22/27 = 2,69 V e 3,3·22/72 = 1,008 V; ΔV = 1,68 V (praticamente igual), porém
centro da faixa mais alto e menor corrente drenada. Regra ótima: fixo ≈ √(5k·50k) ≈ 15,8 k
(ΔV ≈ 1,71 V) — bonificar quem chega nisso. Conclusão: 10 k já é bom; ganho marginal.

**Q3.** f_s/2 = 500 Hz. 30 Hz passa fiel; 700 Hz > Nyquist ⇒ **alias em |1000−700| = 300 Hz**,
indistinguível de um tom real de 300 Hz. Providências: filtro **anti-aliasing analógico**
(passa-baixas antes do ADC, corte < 500 Hz) e/ou elevar f_s (>1,4 kHz) — filtro digital depois
**não** remove alias já criado (ponto-chave). Teorema de Nyquist–Shannon.

**Q4.** Médias (janela deslizante M=4, a partir da 4ª amostra): (100+104+98+500)/4 = 200,5;
(104+98+500+102)/4 = 201; (98+500+102+101)/4 = 200,25. O spike de 500 vira ~+100 espalhado por
3 saídas: atenuado 4×, mas "borrado" (atraso de grupo (M−1)/2 = 1,5 amostras). Mediana de 4 (ou
5) **elimina** o outlier por completo — melhor para ruído impulsivo; média é melhor para ruído
gaussiano contínuo.

**Q5.** f = taxa de atualização/pontos = 3200/32 = **100 Hz**. Para 400 Hz na mesma taxa:
3200/400 = **8 pontos por período** ⇒ senoide "escadeada", forte conteúdo harmônico (visível no
osciloscópio/áudio áspero); mitigável com filtro RC de reconstrução na saída.

**Q6.** Verificação: f_max = 80 MHz/2^12 = 19 531 Hz < 20 000 ⇒ **12 bits não fecham**.
Resolução máxima: 2^N ≤ 80M/20k = 4000 ⇒ N = 11 (2048 ≤ 4000). Duty 25 % em 11 bits:
0,25·2048 = **512 contagens**.

**Q7.** Período 20 ms → 2^14 = 16384 contagens → 1,2207 µs/contagem (16384/20000 µs).
0,6 ms → 0,6/20·16384 ≈ **491**; 1,5 ms → **1229**; 2,4 ms → **1966**. Faixa útil ≈ 1966−491 =
1475 contagens para 180° ⇒ **≈0,12°/contagem** (aceitar 0,1–0,25° conforme faixa adotada).

**Q8.** GPIO fornece poucos mA em 3,3 V; motor exige centenas de mA/tensão maior ⇒ transistor
ou ponte H como chave amplificadora; a ponte H ainda inverte o sentido. Indutância: ao desligar,
L·di/dt gera pico de tensão reversa ⇒ diodo de roda-livre dá caminho à corrente e protege a
chave. GND comum: sem referência única, os níveis lógicos do sinal PWM/direção ficam indefinidos
entre a fonte do motor e a do MCU.

**Q9.** V_motor ≈ 7,4 − 1,4 = **6,0 V** (perfeito para motor de 6 V — é por isso que L298N com
bateria 2S "funciona"). P_ponte ≈ queda × corrente = 1,4 × 0,3 = **0,42 W** por motor (aceitar
consideração de 2 quedas/braço somando ~2 V ⇒ 0,6 W). MOSFETs modernos têm R_DS(on) de mΩ:
P = I²R = 0,09 × ~0,05 = mW ⇒ quase não aquecem e não "roubam" tensão do motor.

**Q10.** 30 Hz está abaixo do limiar de fusão da visão (~60–90 Hz em visão periférica) ⇒
cintilação perceptível; câmeras a 30/60 fps batem em batimento com o PWM ⇒ faixas/flicker no
vídeo. Escolher f ≥ ~200 Hz (nosso lab usa 5 kHz: invisível a olho e a câmera, e fora da faixa
audível de indutores).

**Q11.** 8N1 = start + 8 dados + stop = 10 bits/byte. 8 bytes = 80 bits.
9600: 80/9600 ≈ **8,33 ms**; 115 200: 80/115200 ≈ **0,694 ms**. O overhead de 25 % (2/10) paga a
sincronização assíncrona (sem fio de clock).

**Q12.** Ligação: SCLK/MOSI/MISO comuns; um CS dedicado por escravo (total 3+N fios). Escala
mal: +1 fio por dispositivo e roteamento de CS; vence em velocidade por ser síncrono, push-pull,
full-duplex e sem overhead de endereço (dezenas de MHz). CPOL define nível ocioso do clock;
CPHA define a borda de amostragem — os 4 modos precisam casar entre mestre e escravo.

**Q13.** 7 bits de endereço + 1 bit R/W̄ no primeiro byte após START; o escravo endereçado
responde ACK. Dois MPU-6050: pino AD0 em GND (0x68) e em V_cc (0x69) — endereços distintos.
Scanner: para cada endereço 0x03–0x77, gera START + byte de endereço e verifica **ACK** (basta o
ACK; não lê dados); quem responde ACK "existe".

**Q14.** Dreno aberto: dispositivos só puxam a linha para baixo — permite barramento multiponto
e *clock stretching* sem curto entre saídas; a subida quem faz é o pull-up. R ≤ t_r/(0,8473·C) =
300n/(0,8473·150p) ≈ **2,4 kΩ** (aceitar ~2–2,5 k; os módulos de 4,7 k em paralelo dão 2,35 k; o limite inferior
≈ 970 Ω vem da corrente de 3 mA a 0,4 V). Menor R ⇒ subida rápida
porém mais corrente a cada nível baixo (consumo/aquecimento) e mais esforço dos drivers.

**Q15.** Tabela esperada (resumo): UART — 2 fios ponto-a-ponto, sem clock, ~115 k–3 Mbaud, sem
endereço; uso: console/GPS. SPI — 3+N fios, mestre-escravos, dezenas de MHz, CS como "endereço";
uso: display/SD/ADC rápido. I2C — 2 fios multiponto, até 400 k/1 MHz, endereço de 7 bits; uso:
vários sensores lentos. Escolhas: (a) UART; (b) SPI; (c) I2C.

**Q16.** Dominante (0): transistores puxam CANH↑/CANL↓ (~2 V diferenciais); recessivo (1):
linhas flutuam juntas via terminação. Se alguém transmite 0 e outro 1, o barramento **fica em
0** — o 0 "vence" eletricamente (AND cabeado). É essa assimetria que permite a um transmissor
detectar que perdeu (leu diferente do que enviou) sem destruir o frame vencedor.

**Q17.** 0x2A5 = 010 1010 0101; 0x2B1 = 010 1011 0001. Bits iguais até o 7º transmitido
(MSB→LSB: 0,1,0,1,0,1 iguais; 7º bit: 0x2A5 envia **0**, 0x2B1 envia **1**). 0x2A5 (menor)
vence; 0x2B1 detecta 0 onde enviou 1, cala-se e re-arbitra automaticamente no próximo frame.

**Q18.** Tráfego: 20 msg × 111 bits / 0,020 s = 111 000 bit/s. Carga = 111k/250k = **44,4 %**.
Abaixo de 50 %, mas sem folga para rajadas/erros — aceitável com ressalva; sugerir 500 kbit/s
ou revisão de períodos se o sistema crescer.

**Q19.** CAN: par diferencial terminado ⇒ dezenas de metros, imune a modo comum, arbitragem por
prioridade sem colisão, CRC15+ACK+confinamento de nós defeituosos; rede de equipamentos. I2C:
single-ended com pull-up ⇒ centímetros, sem arbitragem robusta entre mestres (multi-mestre é
frágil), ACK simples; interliga CIs **dentro** da placa. Distância/ruído/EMI do chicote
automotivo inviabilizam I2C fora da placa.

**Q20.** TWAI (controlador, dentro do SoC): monta/decodifica frames, faz stuffing, CRC,
arbitragem lógica, filas e filtros de aceitação — fala **TX/RX em nível lógico 3,3 V**.
SN65HVD230 (transceptor): converte TX/RX para **CANH/CANL diferenciais**, provê imunidade,
proteção e o "AND cabeado" físico. Ligações: ESP32 TX→D do transceptor, RX←R; transceptor→
CANH/CANL no par trançado com 120 Ω nas pontas. Sem transceptor não há camada física válida;
sem controlador não há protocolo.
