/*
 * Lab extra — Medidor de energia PZEM-004T v3.0 no ESP32 (ESP-IDF v5.x)
 * Lê V, I, P, energia, frequência e fator de potência por UART/Modbus-RTU
 * e publica no broker MQTT (arquitetura da semana 14).
 *
 * Ligações (4 fios OBRIGATÓRIOS — o TTL do PZEM é passivo, seção 5.1 da datasheet):
 *   PZEM 5V  -> ESP32 5V (VIN)     |  alimenta os OPTOACOPLADORES (isolam a rede!)
 *   PZEM GND -> ESP32 GND
 *   PZEM TX  -> ESP32 GPIO16 (RX)  |  cruzado: TX do sensor no RX do ESP32
 *   PZEM RX  -> ESP32 GPIO17 (TX)
 *
 * *** SEGURANÇA: o lado CA (L/N + garra CT) é ligado à rede de 220 V.
 *     Essa parte é montada e isolada PELO PROFESSOR. O aluno mexe só no lado TTL. ***
 *
 * Protocolo (datasheet oficial): função 0x04 (Read Input Registers),
 * 10 registradores a partir de 0x0000; baud 9600 8N1; CRC-16/Modbus (poly 0xA001).
 * Mapa: 0x0000 V(0,1V) | 0x0001-2 I(0,001A) | 0x0003-4 P(0,1W) |
 *       0x0005-6 Energia(1Wh) | 0x0007 Freq(0,1Hz) | 0x0008 FP(0,01) | 0x0009 alarme
 */
#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "mqtt_client.h"

/* ---------- CONFIG ---------- */
#define WIFI_SSID   "MINHA_REDE"
#define WIFI_PASS   "MINHA_SENHA"
#define BROKER_URI  "mqtt://192.168.0.10"    /* IP do RPi 3 (broker Mosquitto) */
#define BANCADA     "bancada1"

#define PZEM_UART   UART_NUM_2
#define PZEM_TX     17          /* ESP32 TX -> PZEM RX */
#define PZEM_RX     16          /* ESP32 RX <- PZEM TX */
#define PZEM_ADDR   0xF8        /* endereço geral (ok para 1 sensor no barramento) */

static const char *TAG = "pzem";
static EventGroupHandle_t eg;
#define BIT_IP   BIT0
#define BIT_MQTT BIT1
static esp_mqtt_client_handle_t cli;

/* ---------- CRC-16/Modbus (poly 0xA001) — datasheet, seção 2.7 ---------- */
static uint16_t crc16(const uint8_t *d, int n)
{
    uint16_t crc = 0xFFFF;
    for (int i = 0; i < n; i++) {
        crc ^= d[i];
        for (int b = 0; b < 8; b++)
            crc = (crc & 1) ? (crc >> 1) ^ 0xA001 : (crc >> 1);
    }
    return crc;                 /* devolve low byte primeiro ao serializar */
}

/* ---------- lê os 10 registradores de medição ---------- */
typedef struct { float v, i, p, wh, hz, pf; int alarme; } medida_t;

static bool pzem_ler(medida_t *m)
{
    /* monta requisição: addr + 0x04 + reg_ini(0x0000) + n_regs(0x000A) + CRC */
    uint8_t req[8] = { PZEM_ADDR, 0x04, 0x00, 0x00, 0x00, 0x0A, 0, 0 };
    uint16_t c = crc16(req, 6);
    req[6] = c & 0xFF; req[7] = c >> 8;

    uart_flush(PZEM_UART);
    uart_write_bytes(PZEM_UART, (char *)req, 8);

    /* resposta esperada: addr + 0x04 + 0x14(20 bytes) + 20 dados + 2 CRC = 25 bytes */
    uint8_t rx[25];
    int n = uart_read_bytes(PZEM_UART, rx, 25, pdMS_TO_TICKS(300));
    if (n != 25 || rx[1] != 0x04 || rx[2] != 0x14) {
        ESP_LOGW(TAG, "resposta invalida (n=%d)", n);
        return false;
    }
    uint16_t crc_calc = crc16(rx, 23);
    if ((crc_calc & 0xFF) != rx[23] || (crc_calc >> 8) != rx[24]) {
        ESP_LOGW(TAG, "CRC nao confere");
        return false;
    }

    /* desempacota big-endian (datasheet); pares low/high para I, P, energia */
    #define U16(k) ((rx[3 + 2*(k)] << 8) | rx[4 + 2*(k)])
    uint32_t i_raw = U16(1) | ((uint32_t)U16(2) << 16);     /* low, depois high */
    uint32_t p_raw = U16(3) | ((uint32_t)U16(4) << 16);
    uint32_t e_raw = U16(5) | ((uint32_t)U16(6) << 16);
    m->v  = U16(0) * 0.1f;
    m->i  = i_raw  * 0.001f;
    m->p  = p_raw  * 0.1f;
    m->wh = (float)e_raw;                 /* 1 LSB = 1 Wh */
    m->hz = U16(7) * 0.1f;
    m->pf = U16(8) * 0.01f;
    m->alarme = U16(9) ? 1 : 0;
    #undef U16
    return true;
}

/* ---------- Wi-Fi + MQTT (idênticos ao no_mqtt da semana 14) ---------- */
static void wifi_handler(void *a, esp_event_base_t base, int32_t id, void *data)
{
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START)              esp_wifi_connect();
    else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED){ xEventGroupClearBits(eg, BIT_IP); esp_wifi_connect(); }
    else if (base == IP_EVENT  && id == IP_EVENT_STA_GOT_IP)           xEventGroupSetBits(eg, BIT_IP);
}
static void mqtt_handler(void *a, esp_event_base_t base, int32_t id, void *data)
{
    if ((esp_mqtt_event_id_t)id == MQTT_EVENT_CONNECTED)  xEventGroupSetBits(eg, BIT_MQTT);
    else if ((esp_mqtt_event_id_t)id == MQTT_EVENT_DISCONNECTED) xEventGroupClearBits(eg, BIT_MQTT);
}
static void net_start(void)
{
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();
    wifi_init_config_t wc = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&wc));
    esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, wifi_handler, NULL);
    esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, wifi_handler, NULL);
    wifi_config_t cfg = { 0 };
    strncpy((char *)cfg.sta.ssid, WIFI_SSID, sizeof cfg.sta.ssid);
    strncpy((char *)cfg.sta.password, WIFI_PASS, sizeof cfg.sta.password);
    esp_wifi_set_mode(WIFI_MODE_STA);
    esp_wifi_set_config(WIFI_IF_STA, &cfg);
    esp_wifi_start();
    xEventGroupWaitBits(eg, BIT_IP, pdFALSE, pdTRUE, portMAX_DELAY);

    esp_mqtt_client_config_t mc = { .broker.address.uri = BROKER_URI };
    cli = esp_mqtt_client_init(&mc);
    esp_mqtt_client_register_event(cli, ESP_EVENT_ANY_ID, mqtt_handler, NULL);
    esp_mqtt_client_start(cli);
    xEventGroupWaitBits(eg, BIT_MQTT, pdFALSE, pdTRUE, portMAX_DELAY);
}

static void pub(const char *sub, float val)
{
    char topico[48], msg[16];
    snprintf(topico, sizeof topico, "energia/" BANCADA "/%s", sub);
    snprintf(msg, sizeof msg, "%.3f", val);
    esp_mqtt_client_publish(cli, topico, msg, 0, 0, 0);   /* telemetria: QoS 0 */
}

void app_main(void)
{
    ESP_ERROR_CHECK(nvs_flash_init());
    eg = xEventGroupCreate();

    uart_config_t uc = {
        .baud_rate = 9600, .data_bits = UART_DATA_8_BITS,   /* 9600 8N1: datasheet 2.1 */
        .parity = UART_PARITY_DISABLE, .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE };
    uart_driver_install(PZEM_UART, 256, 0, 0, NULL, 0);
    uart_param_config(PZEM_UART, &uc);
    uart_set_pin(PZEM_UART, PZEM_TX, PZEM_RX, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);

    net_start();
    ESP_LOGI(TAG, "medidor no ar");

    TickType_t prox = xTaskGetTickCount();
    while (1) {
        medida_t m;
        if (pzem_ler(&m)) {
            printf("V=%.1f I=%.3f P=%.1fW E=%.0fWh f=%.1fHz FP=%.2f%s\n",
                   m.v, m.i, m.p, m.wh, m.hz, m.pf, m.alarme ? " [ALARME]" : "");
            /* potência aparente e reativa (didático — teoria, seção 3) */
            float s = m.v * m.i;                 /* VA  */
            float q = sqrtf(fmaxf(0, s*s - m.p*m.p));  /* var */
            pub("tensao", m.v);   pub("corrente", m.i);
            pub("potencia", m.p); pub("aparente", s);   pub("reativa", q);
            pub("energia", m.wh); pub("frequencia", m.hz); pub("fp", m.pf);
        }
        vTaskDelayUntil(&prox, pdMS_TO_TICKS(2000));   /* 0,5 Hz: período cravado (sem. 5) */
    }
}
