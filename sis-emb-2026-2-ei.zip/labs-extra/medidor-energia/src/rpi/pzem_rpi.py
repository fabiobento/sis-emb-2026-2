#!/usr/bin/env python3
"""
Lab extra — Leitura do PZEM-004T v3.0 no Raspberry Pi (Modbus-RTU sobre serial).

Duas formas de ligar o PZEM ao RPi:
  (a) Adaptador USB-TTL (CP2102/CH340) -> /dev/ttyUSB0   (recomendado, isolado do RPi)
  (b) UART do RPi (GPIO14/15) -> /dev/serial0            (exige desabilitar o console serial)

Este script NÃO usa biblioteca de alto nível de propósito: monta o quadro Modbus
"na mão" para que se veja o protocolo (mesmo raciocínio do wr()/rd() da semana 9 e do
firmware ESP32 deste lab). Para produção, use a lib `modbus-tk` ou `pymodbus`.

Dependências:  pip3 install pyserial paho-mqtt --break-system-packages

Uso:  python3 pzem_rpi.py [porta_serial] [host_broker]
      ex.: python3 pzem_rpi.py /dev/ttyUSB0 localhost

*** SEGURANÇA: o lado CA (L/N + garra CT no fio fase) é montado e isolado PELO PROFESSOR. ***
"""
import sys
import time
import struct

import serial            # pyserial
import paho.mqtt.client as mqtt

PORTA = sys.argv[1] if len(sys.argv) > 1 else "/dev/ttyUSB0"
BROKER = sys.argv[2] if len(sys.argv) > 2 else "localhost"
BANCADA = "bancada1"
ADDR = 0xF8              # endereço geral (ok para 1 sensor)


def crc16(data: bytes) -> bytes:
    """CRC-16/Modbus, polinômio 0xA001 (datasheet, seção 2.7). Retorna low, high."""
    crc = 0xFFFF
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = (crc >> 1) ^ 0xA001 if (crc & 1) else (crc >> 1)
    return bytes([crc & 0xFF, crc >> 8])


def ler(ser: serial.Serial):
    """Função 0x04, 10 registradores a partir de 0x0000. Devolve dict ou None."""
    req = bytes([ADDR, 0x04, 0x00, 0x00, 0x00, 0x0A])
    ser.reset_input_buffer()
    ser.write(req + crc16(req))
    resp = ser.read(25)                      # 25 bytes esperados
    if len(resp) != 25 or resp[1] != 0x04 or resp[2] != 0x14:
        return None
    if crc16(resp[:23]) != resp[23:25]:
        return None
    # 10 registradores de 16 bits, big-endian, a partir do byte 3
    regs = struct.unpack(">10H", resp[3:23])
    corrente = (regs[1] | (regs[2] << 16)) * 0.001
    potencia = (regs[3] | (regs[4] << 16)) * 0.1
    energia = (regs[5] | (regs[6] << 16)) * 1.0
    tensao = regs[0] * 0.1
    aparente = tensao * corrente
    reativa = (max(0.0, aparente ** 2 - potencia ** 2)) ** 0.5
    return {
        "tensao": tensao, "corrente": corrente, "potencia": potencia,
        "aparente": aparente, "reativa": reativa, "energia": energia,
        "frequencia": regs[7] * 0.1, "fp": regs[8] * 0.01, "alarme": int(bool(regs[9])),
    }


def main():
    ser = serial.Serial(PORTA, 9600, bytesize=8, parity="N", stopbits=1, timeout=0.5)
    cli = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    cli.connect(BROKER, 1883, 60)
    cli.loop_start()
    print(f"Lendo {PORTA}, publicando em energia/{BANCADA}/# no broker {BROKER}")

    while True:
        m = ler(ser)
        if m:
            print(f"V={m['tensao']:.1f}  I={m['corrente']:.3f}  P={m['potencia']:.1f}W  "
                  f"S={m['aparente']:.1f}VA  Q={m['reativa']:.1f}var  "
                  f"E={m['energia']:.0f}Wh  f={m['frequencia']:.1f}Hz  FP={m['fp']:.2f}"
                  f"{'  [ALARME]' if m['alarme'] else ''}")
            for k, v in m.items():
                cli.publish(f"energia/{BANCADA}/{k}", f"{v:.3f}")
        else:
            print("leitura falhou (CRC/timeout) — normal ocasionalmente; tentando de novo")
        time.sleep(2)


if __name__ == "__main__":
    main()
