#!/usr/bin/env python3
"""
Lab extra — Painel/registro de energia na borda (RPi).
Assina energia/# no broker, grava CSV com timestamp e calcula custo acumulado em R$.

Dependências:  pip3 install paho-mqtt --break-system-packages
Uso:  python3 painel_energia.py [host_broker]   (padrão: localhost)
"""
import csv
import sys
import time

import paho.mqtt.client as mqtt

HOST = sys.argv[1] if len(sys.argv) > 1 else "localhost"
TARIFA_KWH = 0.92          # R$/kWh — ajuste para a tarifa local (EDP ES, bandeira etc.)
ARQ = "energia.csv"

estado = {}                # último valor de cada grandeza


def on_connect(cli, u, flags, rc, props=None):
    print(f"Conectado a {HOST}; assinando energia/#")
    cli.subscribe("energia/#")


def on_message(cli, u, msg):
    grandeza = msg.topic.split("/")[-1]
    try:
        estado[grandeza] = float(msg.payload)
    except ValueError:
        return
    if grandeza == "energia":                       # dispara o registro a cada nova leitura de Wh
        kwh = estado["energia"] / 1000.0
        custo = kwh * TARIFA_KWH
        linha = [time.strftime("%Y-%m-%d %H:%M:%S"),
                 estado.get("tensao", 0), estado.get("corrente", 0),
                 estado.get("potencia", 0), estado.get("fp", 0),
                 estado["energia"], round(custo, 2)]
        with open(ARQ, "a", newline="") as f:
            csv.writer(f).writerow(linha)
        print(f"P={estado.get('potencia',0):.1f}W  FP={estado.get('fp',0):.2f}  "
              f"E={kwh:.3f}kWh  custo=R${custo:.2f}")


cli = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
cli.on_connect = on_connect
cli.on_message = on_message
cli.connect(HOST, 1883, 60)
with open(ARQ, "a", newline="") as f:               # cabeçalho uma vez
    csv.writer(f).writerow(["datahora", "V", "I", "P_W", "FP", "E_Wh", "custo_R$"])
print(f"Gravando em {ARQ} — Ctrl+C para sair")
cli.loop_forever()
