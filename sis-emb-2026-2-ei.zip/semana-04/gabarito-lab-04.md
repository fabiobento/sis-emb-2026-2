# Gabarito — Lab 4 (Sistemas Embarcados, 2026/2)

Uso interno do professor. Cobre os 5 itens de entrega do `lab-04.md`.

> **Nota sobre a numeração do roteiro**: o `lab-04.md` já foi corrigido para referenciar os
> itens **8** e **9** diretamente (a Entrega chegou a citar "Parte B.4"/"Parte B.5", restos
> de uma numeração antiga). Os números abaixo já usam a versão corrigida.

---

## 1. Latências da Parte A (item 7)

10 latências com `vTaskDelay(10 ms)` no laço da tarefa. Valores ilustrativos (os reais
variam por hardware/instante do clique em relação ao tick):

| # | latência (µs) |
|---|---|
| 1 | 812 |
| 2 | 3204 |
| 3 | 6890 |
| 4 | 1204 |
| 5 | 9650 |
| 6 | 4421 |
| 7 | 7733 |
| 8 | 2015 |
| 9 | 5560 |
| 10 | 8902 |

**Média ≈ 5039 µs · Máximo ≈ 9650 µs**

Padrão esperado: os valores se espalham de forma quase uniforme entre ~0 e ~10 000 µs — é
exatamente a **resolução do tick** do `vTaskDelay(10ms)` se manifestando: a ISR captura o
evento quase instantaneamente (poucos µs, garantido pelo hardware), mas a *tarefa* só nota o
flag na próxima vez que acorda do `vTaskDelay`, e isso pode estar em qualquer ponto dentro da
janela de 10 ms desde o clique. Média ≈ metade do período de polling da tarefa (≈5 ms) é o
resultado esperado — se uma dupla reportar média muito próxima de 0 ou muito próxima de
10 000 µs em todas as 10 medidas, vale desconfiar (medição malfeita ou não são realmente 10
cliques distintos).

**Explicação capturar × processar (≤5 linhas, modelo de resposta):** capturar é o que o
hardware garante — a ISR grava o evento e o instante em microssegundos, sempre, não importa
o que mais esteja rodando. Processar é o que a *tarefa* faz com esse dado — e isso está
sujeito ao escalonador: no laço deste lab, a tarefa só verifica o flag a cada 10 ms, então o
evento fica "capturado" instantaneamente mas só é "processado" (impresso) até 10 ms depois.
Nenhum clique se perde; apenas demora um pouco para ser notado.

> **Nota histórica**: versões anteriores deste roteiro tinham um item extra pedindo para
> aumentar o `vTaskDelay` da tarefa para 500 ms e comparar a latência resultante — esse
> item foi removido do `lab-04.md` atual. Se aparecer numa entrega antiga (citando "item 9"
> como a Parte B), não descontar; é só reconhecer que o roteiro mudou.

---

## 2. Item 8 — cenário numérico em que o polling do Lab 3 perderia eventos

Resposta esperada: reprodução do **Exemplo resolvido 4.1** da teoria (não é uma dedução
nova, é a aplicação direta do exemplo já resolvido):

1. Encoder de motor a 3 000 RPM, 20 pulsos/volta → f = (3000/60) × 20 = **1 000 pulsos/s**.
2. Período de um pulso: T = 1 ms.
3. Polling do Lab 3 varre a cada **10 ms** (`vTaskDelay(pdMS_TO_TICKS(10))`, pior caso de
   latência = 10 ms + tratamento).
4. Como T (1 ms) é **dez vezes menor** que o período de varredura (10 ms), a cada scan já
   se passaram ~10 pulsos — o polling captura, na melhor das hipóteses, 1 em cada 10,
   perdendo ~90% da contagem, silenciosamente (a contagem de rotação fica errada sem nenhum
   erro ou aviso).
5. Com interrupção, cada borda é capturada com latência de poucos µs — mais de 1000× mais
   rápido que o próprio período do evento, então nenhuma borda escapa.

**Por que a "metralhadora de cliques" do item 8 não mostrou diferença**: dedos humanos não
passam de ~10–15 cliques/segundo (período ≥ ~70 ms) — muito mais lento que os 10 ms de
varredura do polling. A diferença só aparece quando o **período do evento** se aproxima ou
fica menor que o **período de varredura**, como no encoder. Aceitar respostas que usem outro
periférico rápido (ex.: encoder óptico, saída PWM de outro MCU) desde que o raciocínio
período-do-evento × período-de-varredura esteja correto.

---

## 3. Prints das duas falhas da Parte C (item 9 e item 10)

### Item 9 — `printf` dentro da ISR

> ⚠️ A mensagem exata varia por versão do ESP-IDF/toolchain — não exija bater literalmente
> com o texto abaixo. O que importa reconhecer são as **pistas-chave**: a palavra `abort`
> (ou `Guru Meditation`), um backtrace, e — se o aluno souber ler — uma referência a
> `queue.c`/mutex/lock da newlib, já que `printf` internamente tenta tomar um lock que
> pressupõe contexto de tarefa.

Saída ilustrativa esperada:

```
assert failed: xQueueSemaphoreTake queue.c:1547 (pxQueue->uxQueueType == queueQUEUE_TYPE_MUTEX ...)

Backtrace: 0x40082f31:0x3ffbfff0 0x4008bb35:0x3ffbfff0 0x400d1234:0x3ffbfff0 ...

abort() was called at PC 0x400d1234 on core 0
```

**Explicação esperada**: `printf` (via newlib) usa um mutex interno para proteger os
buffers de stdio — tomar um mutex significa **potencialmente bloquear** esperando outra
tarefa liberá-lo. ISR não pode bloquear (Regra 2 da teoria): não há "outra tarefa" para
retomar depois, o processador inteiro fica preso. O RTOS detecta a tentativa de bloqueio
dentro de contexto de interrupção e aborta o firmware de propósito — é uma proteção, não um
bug aleatório.

### Item 10 — Task WDT (`PROVOCAR_WDT 1`)

```
E (xxxxx) task_wdt: Task watchdog got triggered. The following tasks did not reset the watchdog in time:
E (xxxxx) task_wdt:  - IDLE0 (CPU 0)
```

**Cadeia esperada na explicação do aluno** (o que avaliar):

1. `while(1){}` nu no núcleo 0 nunca cede a CPU (nenhum `vTaskDelay`, nenhum bloqueio).
2. A tarefa IDLE0 (que só roda quando ninguém mais quer a CPU) nunca consegue rodar.
3. É a IDLE0 quem, de rotina, alimenta o Task WDT — sem ela rodar, ninguém alimenta.
4. Passado o timeout (alguns segundos), o Task WDT dispara e imprime a mensagem acima,
   identificando exatamente qual núcleo ficou preso.

Ver `teoria-04.md`, Seção 4 (Figuras 4-H, 4-I e 4-J) para o material de apoio equivalente —
a Figura 4-J em particular já ilustra esse cenário exato (núcleo 0 travado, IDLE0 vs IDLE1).

---

## 4. Código da Parte D (ISR + `gerador_task`) + três leituras

A partir desta edição do lab, a Parte D **não usa mais o botão**: o próprio firmware gera o
pulso (GPIO18) e mede (GPIO4) via um jumper direto entre os dois pinos. Isso elimina o
bounce da equação por completo — o foco vira 100% a técnica de medição.

```c
// Semana 4 — Parte D: medindo a largura de um pulso (ponte com o Exemplo 4.3 / HC-SR04)
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_timer.h"
#include <stdio.h>

#define LED      GPIO_NUM_2
#define IN_PIN   GPIO_NUM_4     // mede a largura do pulso (ISR, GPIO_INTR_ANYEDGE)
#define OUT_PIN  GPIO_NUM_18    // gera o pulso — jumper físico até o IN_PIN

static volatile uint32_t s_pulsos     = 0;
static volatile int64_t  s_duracao_us = 0;
static int64_t s_t1                   = 0;
static volatile bool     s_medindo    = false;

static void IRAM_ATTR in_isr(void *arg)
{
    int64_t agora = esp_timer_get_time();
    int nivel = gpio_get_level(IN_PIN);

    // SEM debounce: o sinal vem de outro GPIO do próprio chip (push-pull, sem
    // contato mecânico) — não existe bounce aqui para filtrar.
    if (nivel == 0) {                        // descida: início do pulso
        s_t1 = agora;
        s_medindo = true;
    } else if (s_medindo) {                  // subida: fim do pulso
        s_duracao_us = agora - s_t1;
        s_medindo = false;
        s_pulsos++;
    }
}

static void heartbeat_cb(void *arg)
{
    static int nivel = 0;
    gpio_set_level(LED, nivel ^= 1);
}

// Gera pulsos de largura CONHECIDA, alternando curto/longo — o "gabarito" contra o
// qual o aluno compara a leitura da ISR.
static void gerador_task(void *arg)
{
    const int larguras_ms[] = { 150, 1200 };
    int i = 0;
    while (1) {
        vTaskDelay(pdMS_TO_TICKS(1000));
        gpio_set_level(OUT_PIN, 0);
        vTaskDelay(pdMS_TO_TICKS(larguras_ms[i]));
        gpio_set_level(OUT_PIN, 1);
        i = (i + 1) % (sizeof(larguras_ms) / sizeof(larguras_ms[0]));
    }
}

void app_main(void)
{
    gpio_reset_pin(LED);
    gpio_set_direction(LED, GPIO_MODE_OUTPUT);

    gpio_reset_pin(OUT_PIN);
    gpio_set_direction(OUT_PIN, GPIO_MODE_OUTPUT);
    gpio_set_level(OUT_PIN, 1);

    gpio_reset_pin(IN_PIN);
    gpio_set_direction(IN_PIN, GPIO_MODE_INPUT);   // sem pull-up: o OUT_PIN comanda o nível
    gpio_set_intr_type(IN_PIN, GPIO_INTR_ANYEDGE);
    gpio_install_isr_service(0);
    gpio_isr_handler_add(IN_PIN, in_isr, NULL);

    const esp_timer_create_args_t targs = { .callback = heartbeat_cb, .name = "hb" };
    esp_timer_handle_t timer;
    esp_timer_create(&targs, &timer);
    esp_timer_start_periodic(timer, 500000);

    xTaskCreate(gerador_task, "gerador", 2048, NULL, 5, NULL);

    uint32_t vistos = 0;
    while (1) {
        if (s_pulsos != vistos) {
            vistos = s_pulsos;
            printf("pulso #%lu | duracao: %lld us (%.1f ms)\n",
                   (unsigned long)vistos, s_duracao_us, s_duracao_us / 1000.0);
        }
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}
```

**Três leituras de exemplo**, comparadas ao programado (item 14/15 pede exatamente essa
comparação):

```
pulso #1 | duracao: 150004 us (150.0 ms)   ← alvo: 150 ms   (erro: +4 us)
pulso #2 | duracao: 1200011 us (1200.0 ms) ← alvo: 1200 ms  (erro: +11 us)
pulso #3 | duracao: 149997 us (150.0 ms)   ← alvo: 150 ms   (erro: −3 us)
```

**Fluxo recomendado ao aluno** (não é item obrigatório de entrega, mas vale conferir se a
dupla seguiu): validar primeiro em simulação no Wokwi com o `Logic Analyzer`, só depois
migrar para hardware real — e, para quem tem o analisador lógico USB físico, repetir a
mesma checagem lá também. Ambos os fluxos estão detalhados no `lab-04.md` (bloco "Comece
pelo Wokwi") e em `docs/instalacao.md`, seções 6.2 (simulação) e 6.3 (hardware físico). Uma
entrega que só mostra os prints do firmware, sem qualquer evidência desse processo, ainda
deve ser aceita — a recomendação é sobre *como depurar*, não um requisito de nota.

---

## 5. Por que `printf` é proibido na ISR e como o firmware contorna

Modelo de resposta (parágrafo):

`printf` não é seguro dentro de uma ISR porque, por baixo, ele precisa de um **mutex** da
newlib para proteger os buffers de stdio compartilhados — e tomar um mutex é uma operação
que pode **bloquear** a tarefa chamadora até outra tarefa liberá-lo. Dentro de uma ISR não
existe "outra tarefa" para o escalonador trocar; bloquear ali travaria o sistema inteiro, e
por isso o RTOS prefere abortar o firmware a permitir isso (item 9). O firmware deste lab
contorna o problema separando **captura** de **exibição**: a ISR só grava um flag (`s_pulsos`,
`s_duracao_us`, ambos `volatile`, Regra 5 da teoria) e devolve o controle imediatamente; é a
*tarefa* principal, rodando em contexto normal (onde bloquear é seguro), que lê esse flag no
seu próprio ritmo e faz o `printf`. O `volatile` garante que o compilador não "cacheie" o
valor lido pela tarefa num registrador — ele precisa reler a variável da memória a cada
volta do laço, já que ela muda "por conta própria" (do ponto de vista da tarefa) dentro da
ISR.

---

## Desafio (opcional) — latência real até a primeira linha da ISR

Ideia: em vez de medir até a *tarefa* notar o evento (o que fizemos no item 1), medimos até
a **primeira linha da ISR** de fato executar — a métrica que a Figura 4-B da teoria chama de
"latência de interrupção" (etapas 1–4: evento → sincronização → salva contexto → despacho).
Como não dá para carimbar um timestamp "antes" da própria ISR rodar, o truque é usar um
**segundo GPIO como testemunha**: ele sobe no instante exato em que a ISR começa a executar,
e um instrumento *externo ao firmware* (o Logic Analyzer do Wokwi) mede a defasagem entre a
borda do botão e a borda desse pino — sem depender de nada que o próprio código informe
sobre si mesmo.

### Mudança no firmware (base: `isr_timer/main.c` da Parte A)

```c
#define BTN       GPIO_NUM_4
#define GPIO_REF  GPIO_NUM_5    // pino "testemunha", só para o Logic Analyzer ver a ISR chegar

static void IRAM_ATTR btn_isr(void *arg)
{
    gpio_set_level(GPIO_REF, 1);    // <<< PRIMEIRA LINHA: marca "a ISR começou agora"

    int64_t agora = esp_timer_get_time();
    if (agora - s_ultimo_evento_us > DEBOUNCE_US) {
        s_ultimo_evento_us = agora;
        s_eventos++;
        s_t_isr = agora;
    }

    gpio_set_level(GPIO_REF, 0);    // desce de novo, para o próximo clique gerar outra borda
}
```

E em `app_main`, configurar o novo pino como saída antes de instalar a ISR:

```c
gpio_reset_pin(GPIO_REF);
gpio_set_direction(GPIO_REF, GPIO_MODE_OUTPUT);
gpio_set_level(GPIO_REF, 0);
```

### Montagem no Wokwi (site, não VS Code — ver conversa da entrega)

Adicione o componente **Logic Analyzer (8 channels)** (`wokwi-logic-analyzer`) ao projeto e
ligue: `D0` → GPIO4 (o botão), `D1` → GPIO5 (`GPIO_REF`), `GND` → GND. Configure o trigger
para começar a gravar sozinho no clique (`triggerMode: "edge"`, `triggerPin: "D0"`,
`triggerLevel: "low"`, já que o botão é ativo-baixo):

```json
{
  "type": "wokwi-logic-analyzer",
  "id": "logic1",
  "attrs": {
    "channelNames": "BTN,ISR_REF",
    "triggerMode": "edge",
    "triggerPin": "D0",
    "triggerLevel": "low"
  }
}
```

```json
[ "logic1:D0", "esp:4",   "green", [] ],
[ "logic1:D1", "esp:5",   "blue",  [] ],
[ "logic1:GND","esp:GND.2","black", [] ]
```

Rode a simulação, aperte o botão, pare a simulação (o Wokwi baixa um `.vcd`) e abra em
[PulseView](https://sigrok.org/wiki/PulseView) — meça o tempo entre a borda de descida do
canal `BTN` (D0) e a borda de subida do canal `ISR_REF` (D1).

### Leitura de exemplo

```
BTN (D0):      desce em t = 100,000 µs
ISR_REF (D1):  sobe   em t = 100,006 µs
──────────────────────────────────────
defasagem ≈ 6 µs
```

**O que avaliar:** o valor exato varia (é simulação, não hardware real — não é uma medida
cycle-accurate da etapa 2 da Figura 4-B), mas deve ficar na casa de **poucos µs**, e
**sempre menor** que a latência até a tarefa medida no item 1 (que ficava na casa dos
milissegundos, dominada pelo `vTaskDelay` do laço). Esse contraste — µs até a ISR vs. ms até
a tarefa — é o ponto central do desafio: a ISR é rápida por natureza; o que demora é a
tarefa *notar* que algo aconteceu.

---

## Pontos de atenção ao corrigir

- **Latências variam por hardware e por instante do clique** — não exigir que os números
  batam com os deste gabarito; o que importa é o **padrão** (Parte A espalhado 0–10 000 µs,
  Parte B.9 espalhado 0–500 000 µs) e a explicação capturar × processar.
- **`DEBOUNCE_US`**: o `isr_timer/main.c` (Parte A) está em 200 000 (200 ms) — subimos esse
  valor mais de uma vez por leituras fantasma em hardware real (ver histórico do
  repositório). Entregas com valores menores (20 000, 50 000...) não devem ser penalizadas:
  o valor certo depende do botão físico e da fiação de cada bancada (mesma lição da Parte C
  do Lab 3). Isso só vale para a Parte A — a Parte D não usa debounce (ver bullet abaixo).
- **Numeração "B.4"/"B.5" já corrigida no roteiro** — se alguma entrega antiga ainda citar
  esses nomes (feita antes da correção), não descontar: o conteúdo é o mesmo dos itens 8/9.
- **Parte D não usa mais botão nem debounce**: a partir desta edição, o pulso vem do próprio
  GPIO18 (via `gerador_task`), então **não deve haver nenhum código de debounce** no código
  da Parte D — se uma entrega ainda tiver `s_ultimo_evento_us`/`DEBOUNCE_US` nessa parte, é
  sinal de que a dupla só copiou o código antigo (baseado em botão) sem adaptar ao novo
  enunciado. Histórico: versões anteriores deste lab usavam o botão físico aqui, e chegaram
  a ter um bug real de debounce assimétrico (só a borda de descida era filtrada) — não se
  aplica mais, mas é útil saber caso apareça uma entrega de um aluno usando material antigo.
- **Nomes de variáveis livres**: `s_medindo`, `s_t1`, `gerador_task` etc. podem ter outros
  nomes — o essencial é (a) `GPIO_INTR_ANYEDGE` configurado, (b) duração = `subida − descida`,
  (c) os dois pulsos gerados terem largura **conhecida e fixa** (não aleatória), para dar ao
  aluno algo determinístico para comparar.
- **Pequena variação numérica nas leituras é esperada** (dezenas de µs, no máximo poucos ms):
  vem do jitter do próprio `vTaskDelay` do `gerador_task`, não é erro de medição da ISR.
- **Desafio — variações aceitáveis**: qualquer GPIO livre serve como `GPIO_REF` (não
  precisa ser o 5); soluções que **não** baixam o pino de volta ao final da ISR (deixando-o
  alto) também são válidas, desde que a primeira borda de subida seja usada na medição —
  só torna cliques repetidos mais difíceis de distinguir no `.vcd`. O essencial é: o
  `gpio_set_level(GPIO_REF, 1)` ser a **primeira instrução executável** da ISR.
- **Backtrace do item 9**: como a mensagem exata do abort varia por versão do ESP-IDF,
  aceitar qualquer print que mostre claramente um abort/panic disparado pelo `printf` dentro
  da ISR — não exigir correspondência literal com o texto deste gabarito.
