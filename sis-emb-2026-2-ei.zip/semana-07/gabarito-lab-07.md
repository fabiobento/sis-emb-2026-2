# Gabarito — Lab 7 (Sistemas Embarcados, 2026/2)

Uso interno do professor. Cobre os 5 itens de entrega do `lab-07.md` (relatório
`lab-07/relatorio.md`) e as perguntas embutidas nos itens do roteiro.

> **Sobre os números**: todos os valores abaixo são **ilustrativos** — calculados a partir
> da teoria ou de simulação, **não** medidos em bancada com as peças do laboratório. Valem
> como ordem de grandeza e como referência de raciocínio; cada ESP32 e cada LDR darão
> números diferentes. Na correção, avalie o **raciocínio e a coerência** (direção certa,
> ordem de grandeza certa, contas feitas com os próprios dados do aluno), não a igualdade
> com esta tabela.

---

## 1. Calibração (Parte A, itens 8 e 9)

**Fórmula** (Figura L7-A): $V_{esp} = 3{,}3 \cdot \frac{10\,\text{k}\Omega}{R_{LDR} + 10\,\text{k}\Omega}$.

Exemplo ilustrativo para um LDR da família GL55xx (o da foto da bancada tem esse aspecto;
as resistências típicas dessa família vão de alguns kΩ sob luz forte a centenas de kΩ no
escuro, e variam muito de peça para peça):

| condição | R do LDR (multímetro) | V esperado (fórmula) | V impresso (`V=`) | raw |
|---|---|---|---|---|
| luz da sala | ≈ 4 kΩ | 2,36 V | ≈ 1,9 V | ≈ 2480 |
| lanterna encostada | ≈ 0,8 kΩ | 3,06 V | ≈ 2,4 V | ≈ 3200 (perto do topo) |
| coberto com a mão | ≈ 400 kΩ | 0,08 V | ≈ 0,06 V | ≲ 100 (zona morta) |

**O que o aluno vai notar, e é esperado**: o `V=` impresso fica **abaixo** do esperado,
tipicamente 10–25 %. A causa principal é a convenção do firmware: `V = filt · 3,1/4095`
trata 3,1 V como fundo de escala, mas o fundo de escala **nominal** do ESP32 com 11 dB é
mais alto (~3,9 V; veja a teoria, seção 1.2). Se o fundo de escala real do chip for 3,9 V,
o `V=` sai ≈ 3,1/3,9 ≈ 0,8× o valor real. Fontes secundárias (todas citadas no roteiro,
item 8): tolerância do resistor de 10 kΩ (±5 %), não linearidade do ADC do ESP32 nas pontas
da faixa (perto de 0 V há uma "zona morta"; perto do topo a curva achata) e o próprio LDR
mudar de resistência com a temperatura e com a luz entre a medida do multímetro e a do ADC.

**Boa resposta do item 8** (qual fonte pesa mais): a conversão com 3,1 V (diferença
sistemática, mesma direção nas três linhas); a não linearidade aparece como erro **maior
nas pontas** (lanterna e coberto) do que no meio (sala). Aceite também "tolerância do
resistor" se o aluno medir o 10 kΩ e mostrar que ele não era 10 kΩ.

**Dois pontos para observar na correção:**

- Com um LDR real sob lanterna encostada, o nó pode ir a **> 3 V** e flertar com a
  saturação; isso não é erro de montagem, é a mesma coisa do item 14.
- Coberto com a mão, o valor pode ficar em ~0 (zona morta do ADC). Se o aluno anotar
  "raw = 0" e "V = 0,00", peça que compare com o V **esperado** (0,05–0,2 V): o ADC não
  consegue distinguir tensões tão baixas, e isso é uma limitação do conversor, não do LDR.

**Item 9 — modelo de resposta**: a física real se afastou do exemplo (8 kΩ/120 kΩ eram
valores nominais didáticos; o LDR da bancada tem outros extremos, e o ADC acrescenta a
distorção acima). Isso não é problema para o controle em malha fechada porque o controlador
age sobre o **erro** (referência − medida): se o sensor lê 20 % a menos, o laço ajusta a
atuação até a *leitura* igualar a referência. Só é preciso que a resposta do sensor seja
**monotônica** (mais luz ⇒ mais tensão, sempre) e razoavelmente repetível. Em malha aberta,
o mesmo desvio viraria erro direto na grandeza controlada.

---

## 2. Ruído × janela M (Parte B, itens 10–13)

Simulação com ruído branco de ~14 contagens, 20 Hz, estatística de 20 amostras por linha,
primeiras linhas descartadas (como no roteiro):

| M | desvio típico (`desvio=`) | √M-teórico (14/√M) | atraso (M−1)/2 amostras |
|---|---|---|---|
| 1 | ≈ 13–14 | 14,0 | 0 ms |
| 4 | ≈ 6 | 7,0 | 75 ms |
| 8 | ≈ 4 | 5,0 | 175 ms |
| 32 | ≈ 1 | 2,5 | 775 ms |

**Atenção, ponto sutil (item 11):** o `desvio` do firmware é calculado sobre **apenas 20
amostras consecutivas** (1 s). Para M pequeno isso reproduz bem a lei 1/√M. Para M grande
(16, 32), a saída da média móvel varia **tão devagar** que, dentro daquela janela de 1 s,
ela mal se mexe — o desvio medido cai **mais** que 1/√M (na simulação, ≈ 1 contra 2,5
previstos para M = 32). Isso é uma propriedade da medição, não um defeito do filtro nem do
experimento; a Figura L7-C mostra a lei teórica (desvio de longo prazo). Se um aluno reportar
"caiu mais que √M para M = 32", a resposta dele está **correta** — é o sinal de que
entendeu que o ruído filtrado é correlacionado entre amostras. Se reportar que o desvio
quase **não** caiu, procure:

- oscilação **lenta** da luz da sala, sombra ou mão (a média não remove variação lenta — é
  informação, não ruído); ou
- fluorescente/LED piscando a 100/120 Hz fazendo alias (Exemplo 7.3b da teoria): com
  $f_s$ = 20 Hz isso vira nível constante ou deriva lenta, que também a média não toca.

**Partida a frio**: a primeira linha (e, com M = 32, a segunda) vem com `filt` subindo desde
zero; o desvio impresso ali é enorme (centenas de contagens). Se o aluno incluir essas
linhas na tabela, esse é o erro mais comum desta parte — veja "Erros frequentes".

**Item 12 (sentir o atraso)**: com M = 32 a resposta atrasa ~775 ms (50 % do degrau) e leva
~1,6 s para assentar. A hipótese correta para o relatório: o filtro "enxerga" o passado — a
média de 32 amostras ainda contém, por 1,6 s, valores de antes de a mão chegar.

**Item 13 — spike sintético (M = 4)**, exemplo de trecho de log esperado (base ≈ 2400, um
flash de lanterna que satura uma única amostra em 4095):

```
raw=2403  filt=2402  ...
raw=4095  filt=2826  ...   ← entra o spike: (3·2400 + 4095)/4
raw=2398  filt=2825  ...   ← continua 4 saídas seguidas
raw=2405  filt=2826  ...
raw=2401  filt=2826  ...
raw=2399  filt=2402  ...   ← o spike sai da janela
```

O spike (+1695) é atenuado ~4× (+424) e **espalhado por 4 amostras** — mesma lição do
Exemplo 7.4. Um flash real dura mais de uma amostra a 20 Hz (50 ms cada), então o aluno verá
um platô maior e menos "limpo" que o do exemplo; aceite.

**Bônus** (spike isolado e enorme — média ou mediana?): **mediana**. Ela ordena a janela e
pega o valor central; um único valor extremo é descartado por completo, sem espalhar. A
média o atenua mas o distribui por M saídas. Ressalva para nota alta: a mediana não é
melhor para ruído **contínuo** (gaussiano), onde a média faz o trabalho de forma mais
eficiente.

---

## 3. Saturação e projeto 0–5 V (Parte C, itens 14–15)

**Item 14**: com o GPIO34 direto no 3V3, esperado `raw=4095` cravado e `filt=4095`,
`V=3,100` (a fórmula do firmware satura em 3,1 V mesmo com 3,3 V no pino). Qualquer tensão
entre ≈ 3,1 e 3,3 V produz o **mesmo** código: informação perdida. Em alguns chips a
saturação pode começar um pouco antes de 3,1 V; não é erro.

**Item 15 — modelo de resposta**:

- *Opção A (divisor)*: dois resistores iguais (10 kΩ + 10 kΩ) ⇒ o ADC vê metade da tensão;
  com o sensor em 5 V, o nó fica em **2,5 V**, abaixo do teto de 3,1 V (sem saturar). O
  sensor usa 2,5/3,1 ≈ **81 %** da faixa do ADC (≈ 3300 dos 4096 códigos).
- Custo: o LSB, medido em volts **do sensor**, dobra: 0,757 mV × 2 ≈ **1,5 mV**. Ou seja,
  perde-se resolução em troca de caber na faixa.
- *Opção B (ADC externo)*: um conversor de faixa maior/mais bits (o ADS1115 aparece nas
  figuras do repositório, com ganho programável) evita o divisor e ainda melhora a
  resolução; custa um componente a mais e um barramento I²C (semana 9).
- Ponto adicional (bom, não obrigatório): o divisor também protege o pino do ESP32 contra
  os 5 V do sensor — e **nunca** ligar 5 V direto no GPIO (aviso do topo do lab).

---

## 4. DAC e valor eficaz (Parte D, itens 16–21)

**Item 20 — multímetro**:

- **VDC ≈ 1,65 V** (nível médio da senoide: a tabela vai de 0 a 255 códigos, ou seja, 0 a
  3,3 V, centrada em 1,65 V).
- **VAC ≈ 1,1–1,2 V**: $V_{rms} = A/\sqrt{2} = 1{,}65/1{,}41 \approx 1{,}17$ V. O multímetro em
  VAC acopla em CA (ignora o nível CC), por isso lê só a parte alternada. Um multímetro
  barato que **não** seja true-RMS lê a média retificada × 1,11, que para uma senoide dá o
  mesmo valor; a escada (harmônicos) e o limite de banda do aparelho podem deslocar o valor
  em alguns por cento. Se o aluno ler ~0,8 ou ~1,65 V em VAC, suspeite de aparelho/escala
  errada (VDC/mV) ou de ponteira no pino errado.

**Item 21 — callback do `esp_timer`**: a 440 Hz com 8 pontos por ciclo, a atualização é
440 × 8 = **3520 Hz**, período ≈ 284 µs; com 32 pontos, 440 × 32 = **14 080 Hz**, período
≈ 71 µs. Para o "ouvir", o ponto pedagógico é que 8 pontos por ciclo produzem uma escada
grosseira, cheia de harmônicos (timbre áspero), enquanto 32 pontos aproximam melhor a
senoide. **Aviso para a bancada**: não testei a 14 kHz no `esp_timer` do ESP32; se algum
aluno relatar travamento, jitter audível ou watchdog nessa configuração, é limite de
taxa do timer/CPU, não erro conceitual — reduza `NPTS` para 16 e prossiga.

---

## 5. Loopback e aliasing (Parte E, itens 22–25, opcional)

Cálculos conferidos em C com a mesma fórmula do firmware (período do timer inteiro em µs):

| `F_HZ` | frequência real do DAC | amostras/ciclo ($f_s/f$) | alias previsto | o que o gráfico mostra |
|---|---|---|---|---|
| 2 | 2,00 Hz | 10 | — | senoide lenta, fiel (período ≈ 10 amostras) |
| 8 | 8,00 Hz | 2,5 | — (o firmware imprime 8,00 Hz: k = 0) | legítima, mas irregular: padrão repete a cada 5 amostras |
| 95 | ≈ 95,27 Hz | 0,21 | ≈ **4,73 Hz** | senoide lenta (período ≈ 4,2 amostras) que **não existe** no sinal |
| 100 | ≈ 100,16 Hz | 0,20 | ≈ **0,16 Hz** | quase uma reta, derivando lentamente (período ≈ 6 s) |

Observações:

- No caso de **8 Hz**, a linha "alias previsto = 8,00 Hz" do firmware pode confundir: a
  fórmula usa k = round(f/fs) = round(0,4) = 0, ou seja, "sem dobra". É o comportamento
  correto (8 Hz < 10 Hz); a irregularidade visual vem de só haver 2,5 amostras por ciclo.
- No caso de **100 Hz**, o **nível** em que a "reta" fica depende da fase de partida (cada
  gravação dá um valor diferente entre ~0,35 V e ~2,9 V). Se o aluno vir sempre exatamente o
  mesmo valor e nenhuma deriva em minutos, desconfie do jumper/da configuração.
- A deriva lenta de 0,16 Hz existe porque o `esp_timer` (inteiro em µs) e o tick do
  FreeRTOS não são exatamente comensuráveis; é o mesmo mecanismo de "respiração fantasma"
  do Exemplo 7.3b da teoria.
- Não testei o firmware `loopback_alias` em placa: se algum caso destoar muito da tabela,
  considere a possibilidade de erro no firmware antes de culpar o aluno.

**Item 25 — modelo de resposta**: filtro RC passa-baixas **antes** do pino do ADC (teoria,
seção 3.4). Com $f_s$ = 20 Hz, a frequência de Nyquist é 10 Hz; para uma banda útil de, por
exemplo, 2 Hz, escolhe-se $f_c$ ≈ 3–5 Hz. Exemplo: R = 10 kΩ, C = 4,7 µF ⇒
$f_c = 1/(2\pi RC) \approx 3{,}4$ Hz. Atenuação em 95 Hz: $|H| = 1/\sqrt{1 + (95/3{,}4)^2}
\approx 0{,}036$ ⇒ ≈ **−29 dB**; em $f_s/2$ = 10 Hz: ≈ −10 dB.

**Por que um RC sozinho não basta**: o RC não é uma parede (−20 dB/década). Em $f_s/2$
ele só atenua ≈ 10 dB, então componentes logo acima de 10 Hz ainda passam com boa parte da
amplitude e viram alias. Mesmo os −29 dB em 95 Hz deixam passar ~3,6 % da amplitude: para
uma senoide de ≈ 1,3 V de amplitude, ≈ 45 mV ≈ 60 LSB — um alias residual pequeno, porém
visível. Defesa completa: RC + $f_s$ com folga (5–10× a banda de interesse) + (se preciso)
filtro de ordem maior.

---

## Erros frequentes e como reconhecer

| Sintoma na entrega | Causa mais provável | Como orientar |
|---|---|---|
| Desvio gigante (centenas) para M = 4/8/32 | incluiu a 1ª linha (partida a frio do buffer) | descartar a(s) 1ª(s) linha(s), item 5 do roteiro |
| `V=` bem abaixo da fórmula nas três linhas | convenção 3,1 V × fundo de escala real do ADC | é esperado; não é erro de montagem (seção 1 deste gabarito) |
| Leitura **sobe** no escuro | LDR e 10 kΩ trocados | LDR em cima (3V3), 10 kΩ embaixo |
| `raw=0` coberto | zona morta do ADC perto de 0 V | mostrar o V **esperado** pela fórmula; limitação do conversor |
| Desvio não cai com M | luz lenta/flicker (alias), sombra, mão | medir com o LDR coberto e a sala estável |
| Tabela "alias" do loopback inventada, igual à teoria, sem gráfico | não executou a Parte E | pedir o print do monitor/gráfico de pelo menos um caso (95 ou 100 Hz) |
| Loopback saturando no topo | amplitude da tabela mudada de volta para 127,5 | manter 100 (≈ 0,35–2,9 V) |
| LDR do circuito ainda ligado ao GPIO34 durante o loopback | competição com o DAC | só o jumper GPIO25→GPIO34 no pino |

---

## Checagens antes de aplicar o lab em sala

1. **`diagram.json` do item 1 (potenciômetro)**: escrito sem testar no Wokwi; conferir os
   pinos `VCC`/`SIG`/`GND` do `wokwi-potentiometer` e o `esp:GND.1`.
2. **`loopback_alias/main.c`**: não compilado nem gravado em placa; os valores da seção 5
   foram calculados em C puro com a mesma fórmula.
3. **14 kHz no `esp_timer`** (item 21 com 32 pontos): não testado.
4. **LDRs**: medir 2–3 peças da bancada com multímetro (luz da sala, lanterna, coberto)
   para saber a faixa real antes de a turma chegar; se o LDR for do tipo da foto (GL55xx),
   a lanterna encostada provavelmente leva o nó a > 3 V.
5. Lembrar a turma do aviso ⚠️ do topo do lab (máximo 3,3 V nos pinos).
