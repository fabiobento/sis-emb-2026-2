#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "soc/gpio_reg.h"      
#include "driver/gpio.h"

#define BIT_LED (1u << 2)      // GPIO 2 → bit 2 dos registradores de GPIO 0–31

void app_main(void)
{
    gpio_reset_pin(GPIO_NUM_2);
    
    // RESOLUÇÃO DO DESAFIO: 
    // Configura a direção como saída de forma ATÔMICA usando W1TS.
    // Note que usamos o sinal de igual (=) direto, sem o OU bit a bit (|=).
    *(volatile uint32_t *)GPIO_ENABLE_W1TS_REG = BIT_LED;

    // Ponteiros para os registradores atômicos de SAÍDA (estado do pino)
    volatile uint32_t *w1ts = (volatile uint32_t *)GPIO_OUT_W1TS_REG; 
    volatile uint32_t *w1tc = (volatile uint32_t *)GPIO_OUT_W1TC_REG; 

    while (1) {
        *w1ts = BIT_LED;                    // liga (atômico)
        vTaskDelay(pdMS_TO_TICKS(250));
        *w1tc = BIT_LED;                    // desliga (atômico)
        vTaskDelay(pdMS_TO_TICKS(250));
    }
}