Para resolver esse desafio, o objetivo é aplicar o mesmo conceito de atomicidade que vimos na saída (OUT) para a configuração de direção (ENABLE). Em vez de usar a operação de "lê-modifica-escreve" (`|=`) no `GPIO_ENABLE_REG`, vamos usar uma escrita direta (atômica) no registrador dedicado `GPIO_ENABLE_W1TS_REG`.


```c
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "soc/gpio_reg.h"      
#include "driver/gpio.h"

#define BIT_LED (1u << 2)      // GPIO 2 → bit 2 dos registradores de GPIO 0–31

void app_main(void)
{
    gpio_reset_pin(GPIO_NUM_2);
    
    // RESOLUÇÃO DO DESAFIO: 
    // Configura a direção como saída de forma ATÔMICA usando W1TS.
    // Note que usamos o sinal de igual (=) direto, sem o OU bit a bit (|=).
    *(volatile uint32_t *)GPIO_ENABLE_W1TS_REG = BIT_LED;

    // Ponteiros para os registradores atômicos de SAÍDA (estado do pino)
    volatile uint32_t *w1ts = (volatile uint32_t *)GPIO_OUT_W1TS_REG; 
    volatile uint32_t *w1tc = (volatile uint32_t *)GPIO_OUT_W1TC_REG; 

    while (1) {
        *w1ts = BIT_LED;                    // liga (atômico)
        vTaskDelay(pdMS_TO_TICKS(250));
        *w1tc = BIT_LED;                    // desliga (atômico)
        vTaskDelay(pdMS_TO_TICKS(250));
    }
}

```

### Explicação para o Relatório (O paralelo OUT/ENABLE)

A explicação técnica do paralelo exigido no desafio é a seguinte:

**O paralelo entre OUT e ENABLE é estrutural: a arquitetura do ESP32 aplica a mesma solução de segurança (registradores W1TS/W1TC) para diferentes blocos de controle de hardware.**

Assim como o registrador de estado dos pinos (`GPIO_OUT_REG`) é vulnerável a condições de corrida se for modificado com `|=` e `&= ~`, o registrador que controla a direção dos pinos (`GPIO_ENABLE_REG`) sofre exatamente do mesmo problema de "lê-modifica-escreve".

Se uma interrupção tentar configurar um pino como saída ao mesmo tempo em que a função principal tenta configurar outro pino, a configuração de um deles pode ser perdida.

Para resolver isso, a Espressif espelhou o design:

* Para mudar o **estado (nível lógico)** de forma segura, existem o `GPIO_OUT_W1TS_REG` e o `GPIO_OUT_W1TC_REG`.
* Para mudar a **direção (habilitar/desabilitar saída)** de forma segura, existem o `GPIO_ENABLE_W1TS_REG` (que liga o bit de enable) e o `GPIO_ENABLE_W1TC_REG` (que desliga o bit de enable).

O uso de ambos garante que toda a manipulação do pino, desde a sua configuração inicial até o seu acionamento em loop, seja 100% atômica e imune a interrupções.